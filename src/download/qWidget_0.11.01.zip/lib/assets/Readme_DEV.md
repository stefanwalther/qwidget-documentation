# Dev Note

The folder assets should only be used for logical components used by widgets, **not by the core code**.