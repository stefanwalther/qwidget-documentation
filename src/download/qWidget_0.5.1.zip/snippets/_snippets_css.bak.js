{
    "snippets": [
    {
        "name"  :   "Simple Button",
        "desc"  :   "A simple button style. Use class= to reference the style class.",
        "key"   :   "css/1_button",
        "cat"   :   "css"
    },
    {
        "name"  :   "Styles for Div-tables",
        "desc"  :   "Basic styles for div-tables",
        "key"   :   "css/2_divtablestyles",
        "cat"   :   "css"
    }
]
}


