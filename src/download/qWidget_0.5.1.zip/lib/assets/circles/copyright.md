* **wi-Circles** realized using the following sources:
	* dkCircles - https://github.com/kapusta/circles - copyright Daniel Kapusta - MIT-LICENSE
	* Circles - https://github.com/lugolabs/circles - copyright Artan Sinani - MIT-LICENSE
        