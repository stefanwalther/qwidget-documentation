# ng-color-picker

Taken from https://github.com/joujiahe/ng-color-picker/