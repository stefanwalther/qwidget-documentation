define([ "angular", "qvangular", "qlikview" ], function(a, b, c) {
    "use strict";
    b.service("wiSysInfoService", [ "$q", function() {
        function b(a) {
            void 0 === a.apps && (a.apps = []), c.getAppList(function(b) {
                a.apps.length = 0, a.apps = b;
            });
        }
        function d(a, b) {
            void 0 === a.sheets && (a.sheets = []), b.getAppObjectList(function(b) {
                a.sheets.length = 0, _.each(b.qAppObjectList.qItems, function(b) {
                    a.sheets.push(b);
                });
            });
        }
        function e(a, b) {
            void 0 === a.fields && (a.fields = []), b.getList("FieldList", function(b) {
                a.fields.length = 0, _.each(b.qFieldList.qItems, function(b) {
                    a.fields.push(b);
                });
            });
        }
        function f(a, b) {
            void 0 === a.measures && (a.measures = []), b.getList("MeasureList", function(b) {
                a.measures.length = 0, _.each(b.qMeasureList.qItems, function(b) {
                    a.measures.push(b);
                });
            });
        }
        function g(a, b) {
            void 0 === a.dimensions && (a.dimensions = []), b.getList("DimensionList", function(b) {
                a.dimensions.length = 0, _.each(b.qDimensionList.qItems, function(b) {
                    a.dimensions.push(b);
                });
            });
        }
        function h(a, b) {
            void 0 === a.extensions && (a.extensions = []), b.getList("ExtensionList", function(b) {
                console.log("-ExtensionList", b), a.extensions.length = 0, b.qExtensionList && _.each(b.qExtensionList.qItems, function(b) {
                    a.extensions.push(b);
                });
            });
        }
        function i(a, b) {
            void 0 === a.bookmarks && (a.bookmarks = []), b.getList("BookmarkList", function(b) {
                a.bookmarks.length = 0, b.qBookmarkList && _.each(b.qBookmarkList.qItems, function(b) {
                    a.bookmarks.push(b);
                });
            });
        }
        function j(a, b) {
            void 0 === a.currentselections && (a.currentselections = []), b.getList("CurrentSelections", function(b) {
                a.currentselections.length = 0, a.currentselections = b.qSelectionObject;
            });
        }
        function k(b, c, d) {
            var e = "visualizations";
            d && (e = "visualizationDetails"), void 0 === b[e] && (b[e] = []), c.getAppObjectList(function(f) {
                b[e].length = 0, _.each(f.qAppObjectList.qItems, function(f) {
                    console.log("sheet", f), _.each(f.qData.cells, function(g) {
                        var h = g.name;
                        console.log("sheet " + f.qMeta.title + " element meta data:", g), c.getObject(h).then(function(c) {
                            console.log("Model returned for " + h, c);
                            var g = {};
                            g.footnote = a.copy(c.footnote), g.metadata = a.copy(c.metadata), g.showTitles = a.copy(c.showTitles), 
                            g.qInfo = a.copy(c.qInfo), g.subtitle = a.copy(c.subtitle), g.title = a.copy(c.title), 
                            g.version = a.copy(c.version), g.visualization = a.copy(c.visualization), g.visualizationType = a.copy(c.visualizationType), 
                            g.qExtendsId = a.copy(c.qExtendsId), g.usedOnSheet = {}, g.usedOnSheet.title = a.copy(f.qData.title), 
                            g.usedOnSheet.qInfo = a.copy(f.qInfo), g.usedOnSheet.qMeta = a.copy(f.qMeta), g.visualizationTypeIcon = l(c.qInfo.qType), 
                            d && (g.obj = a.copy(c)), b[e].push(g);
                        });
                    });
                });
            });
        }
        function l(a) {
            switch (a) {
              case "bar-chart-vertical":
                return "icon-bar-chart-vertical";

              case "line-chart":
                return "icon-line-chart";

              case "table":
                return "icon-table";

              case "pivottable":
                return "icon-table";

              case "components":
                return "icon-components";

              case "pie-chart":
                return "icon-pie-chart";

              case "filterpane":
                return "icon-filterpane";

              case "list":
                return "icon-list";

              case "gauge-chart":
                return "icon-gauge-chart";

              case "scatter-chart":
                return "icon-scatter-chart";

              case "text-image":
                return "icon-text-image";

              case "text":
                return "icon-titletext";

              case "map":
                return "icon-map";

              case "combo-chart":
                return "icon-combo-chart";

              default:
                return "icon-extension";
            }
        }
        function m(a, b) {}
        return {
            loadData: function(a, l) {
                for (var n = c.currApp(), o = 0; o < l.length; o++) {
                    var p = l[o];
                    switch (p.toLowerCase()) {
                      case "apps":
                        b(a);
                        break;

                      case "sheets":
                        d(a, n);
                        break;

                      case "fields":
                        e(a, n);
                        break;

                      case "measures":
                        f(a, n);
                        break;

                      case "dimensions":
                        g(a, n);
                        break;

                      case "extensions":
                        h(a, n);
                        break;

                      case "bookmarks":
                        i(a, n);
                        break;

                      case "currentselections":
                        j(a, n);
                        break;

                      case "visualizations":
                        k(a, n, !1);
                        break;

                      case "visualizationdetails":
                        k(a, n, !0);
                        break;

                      case "masterobjects":
                        m(a, n);
                    }
                }
            }
        };
    } ]);
});