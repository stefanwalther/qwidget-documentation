define([ "jquery", "qvangular", "text!./wiSysInfo.ng.html", "./wiSysInfoService" ], function(a, b, c) {
    "use strict";
    b.directive("wiSysInfo", [ "$compile", "wiSysInfoService", function(a, b) {
        return {
            restrict: "E",
            replace: !0,
            scope: !0,
            priority: 0,
            controller: [ "$scope", function(a) {
                a.selectedTab = "apps";
            } ],
            link: function(d, e, f) {
                var g = [ "apps", "sheets", "fields", "measures", "dimensions", "extensions", "bookmarks", "currentselections" ], h = function() {
                    var a = f.content ? f.content.split(",") : g;
                    console.log("wiSysInfo:contents:", a), d.items = b.loadData(d, a);
                };
                h();
                var i;
                i && i.$destroy(), i = d.$new(), e.contents() && e.contents().context && e.contents().context.innerHTML.trim().length > 0 ? a(e.contents())(i) : (e.empty(), 
                e.append(c), a(e.contents())(i));
            }
        };
    } ]);
});