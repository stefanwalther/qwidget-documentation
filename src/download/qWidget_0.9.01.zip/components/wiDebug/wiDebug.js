define([ "jquery", "qvangular", "angular" ], function(a, b, c) {
    "use strict";
    b.directive("wiDebug", [ "$timeout", function() {
        return {
            restrict: "E",
            scope: {
                object: "=?"
            },
            replace: !0,
            link: function(b, d) {
                function e(a) {
                    return '<span class="prop">' + a + "</span>";
                }
                function f() {
                    return '<span class="dot">:</span>';
                }
                function g(a) {
                    return _.isArray(a) ? '<span class="obj">Array[' + a.length + "]</span>" : '<span class="obj">Object</span>';
                }
                function h() {
                    return null;
                }
                function i(a) {
                    return _.isString(a) ? '<span class="str">"' + a + '"</span>' : _.isNumber(a) ? '<span class="num">' + a + "</span>" : _.isBoolean(a) ? '<span class="bool">' + a + "</span>" : a;
                }
                function j(b, c, d) {
                    var e = a(document.createElement("ul"));
                    d && e.addClass("tree"), k(b, e), e.children().length > 0 && c.append(e);
                }
                function k(b, c) {
                    for (var d in b) if (b.hasOwnProperty(d)) if ("object" == typeof b[d]) {
                        var j = a(document.createElement("li"));
                        j.attr("data-path", d), _.isArray(b[d]) ? j.attr("data-type", "array") : j.attr("data-type", "object"), 
                        j.html('<a href="javascript:void(0);">' + e(d) + f() + g(b[d]) + "</a>");
                        var l = a(document.createElement("ul"));
                        k(b[d], l, !1), j.append(l), c.append(j);
                    } else {
                        var m = a(document.createElement("li"));
                        m.attr("data-path", d), m.attr("data-type", "property"), m.html(e(d) + f() + i(b[d])), 
                        m.append(h(d)), c.append(m);
                    }
                }
                var l = a(document.createElement("div"));
                l.addClass("wi-dbg");
                var m = function(b) {
                    var c = [], d = {};
                    for (var e in b) b.hasOwnProperty(e) && c.push(e);
                    return c.sort(), a.each(c, function(c, e) {
                        var f = b[e];
                        if (f instanceof Array) {
                            var g = [];
                            a.each(f, function() {
                                g.push(m(this));
                            }), f = g;
                        } else f instanceof Object && (f = m(f));
                        d[e] = f;
                    }), d;
                }, n = {
                    collapse: function(a) {
                        a.slideToggle(200);
                    },
                    init: function() {
                        a("a", ".tree").each(function() {
                            {
                                var b = a(this);
                                b.parent();
                            }
                            if (b.next().is("ul")) {
                                var c = b.next();
                                b.click(function(a) {
                                    a.preventDefault(), n.collapse(c), b.toggleClass("active");
                                });
                            }
                        });
                    }
                }, o = c.copy(b.object);
                o = m(o), j(o, l, !0), d.replaceWith(l), n.init();
            }
        };
    } ]);
});