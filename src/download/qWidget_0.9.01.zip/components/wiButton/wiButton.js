define([ "jquery", "qvangular", "angular", "./../../modules/utils/wiUtils", "text!./../wiBootstrap/css/wiBootstrap.css" ], function(a, b, c, d, e) {
    "use strict";
    d.addStyleToHeader("wiBootstrap", e), b.directive("wiButton", function() {
        var a = function(a, b) {
            b.addClass("wi-bs");
        };
        return {
            restrict: "E",
            transclude: !0,
            scope: !0,
            replace: !1,
            link: a
        };
    });
});