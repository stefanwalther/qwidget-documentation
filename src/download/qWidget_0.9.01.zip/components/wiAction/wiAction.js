define([ "jquery", "qvangular", "angular", "./../../modules/utils/wiUtils", "qlikview", "./wiActionService" ], function(a, b, c, d, e) {
    "use strict";
    b.directive("wiAction", [ "$compile", "$timeout", "$parse", "wiActionService", function(a, c, f, g) {
        return {
            restrict: "A",
            scope: !1,
            link: function(a, f, h) {
                function i(c, d, e) {
                    switch (c) {
                      case "gotoSheet":
                      case "bookmark.apply":
                      case "bookmark.create":
                      case "bookmark.remove":
                      case "variable.create":
                      case "variable.setContent":
                        g.e(d);
                        break;

                      case "field.clear":
                      case "field.clearOther":
                      case "field.selectAll":
                      case "field.selectAlternative":
                      case "field.selectExcluded":
                      case "field.selectMatch":
                      case "field.selectPossible":
                      case "field.toggleSelect":
                        g.e(d);
                        break;

                      case "clearAll":
                        e.clearAll();
                        break;

                      case "back":
                        e.back();
                        break;

                      case "forward":
                        e.forward();
                        break;

                      case "lockAll":
                        e.lockAll();
                        break;

                      case "unlockAll":
                        e.unlockAll();
                        break;

                      case "selectValues":
                        a.$eval(d);
                        break;

                      case "nextSheet":
                        e.getAppObjectList(function(a) {
                            var c = a.qAppObjectList.qItems.filter(function(a) {
                                return a.qInfo.qId === b.$rootScope.State.model.id ? !0 : !1;
                            }), d = a.qAppObjectList.qItems.indexOf(c[0]), e = "";
                            console.debug(a.qAppObjectList.qItems), e = d < a.qAppObjectList.qItems.length - 1 ? a.qAppObjectList.qItems[d + 1].qInfo.qId : a.qAppObjectList.qItems[0].qInfo.qId, 
                            b.$rootScope.State.isInEditMode() || (window.location.href = document.URL.replace(b.$rootScope.State.model.id, e));
                        });
                        break;

                      case "prevSheet":
                        e.getAppObjectList(function(a) {
                            var c = a.qAppObjectList.qItems.filter(function(a) {
                                return a.qInfo.qId === b.$rootScope.State.model.id ? !0 : !1;
                            }), d = a.qAppObjectList.qItems.indexOf(c[0]), e = "";
                            e = 0 === d ? a.qAppObjectList.qItems[a.qAppObjectList.qItems.length - 1].qInfo.qId : a.qAppObjectList.qItems[d - 1].qInfo.qId, 
                            console.log("Switching to : " + e), b.$rootScope.State.isInEditMode() || (window.location.href = document.URL.replace(b.$rootScope.State.model.id, e));
                        });
                    }
                }
                a.selectValues = function(b, d, e) {
                    c(function() {
                        a.$parent.backendApi.selectValues(b, [ d ], e);
                    }, 0, !1);
                };
                var j = h.wiAction;
                console.log("actionsAttr", j);
                var k = j.split(";");
                console.log("actionsArray", k);
                var l = e.currApp();
                f.on("qv-activate", function() {
                    for (var a = 0; a < k.length; a++) {
                        var b = k[a];
                        if (void 0 !== b) {
                            b = b.trim();
                            var c = d.fnFromString(b);
                            console.log("execute method", c), console.log("--action", b), i(c, b, l);
                        }
                    }
                }), a.$on("$destroy", function() {
                    f.unbind("qv-activate");
                });
            }
        };
    } ]);
});