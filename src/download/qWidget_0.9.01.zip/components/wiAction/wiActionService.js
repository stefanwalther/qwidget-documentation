define([ "angular", "qvangular", "qlikview", "../../modules/utils/wiUtils" ], function(angular, qvangular, qlikview, wiUtils) {
    "use strict";
    var getCurrAppDocId = function() {
        var a = document.location.pathname, b = a.substr(a.indexOfNth("/", 2) + 1);
        return b.substr(0, b.indexOf("/sheet"));
    };
    qvangular.service("wiActionService", [ "$q", "$timeout", function(q, timeout) {
        return {
            e: function(o) {
                eval("this." + o);
            },
            gotoSheet: function(a) {
                console.log("gotoSheet", a), console.log("location", document.location);
                var b = document.location.protocol, c = document.location.host, d = getCurrAppDocId(), e = qlikview.currApp();
                console.debug(e);
                var f = b + "//" + c + "/sense/app/" + d + "/sheet/" + a + "/state/analysis";
                location.href = f;
            },
            bookmark: {
                apply: function(a) {
                    var b = qlikview.currApp();
                    b.bookmark.apply(a);
                },
                create: function(a, b) {
                    var c = qlikview.currApp();
                    c.bookmark.create(a, b);
                },
                remove: function(a) {
                    var b = qlikview.currApp();
                    b.bookmark.remove(a);
                }
            },
            variable: {
                create: function(a) {
                    var b = qlikview.currApp();
                    b.variable.create(a).then(function(a) {
                        console.log("variable.create", a);
                    });
                },
                setContent: function(a, b) {
                    var c = qlikview.currApp();
                    c.variable.setContent(a, b).then(function(a) {
                        console.log("variable.setContent", a);
                    });
                }
            },
            field: {
                clear: function(a) {
                    var b = qlikview.currApp();
                    b.field(a).clear();
                },
                clearOther: function(a, b) {
                    var c = qlikview.currApp();
                    c.field(a).clearOther(b);
                },
                lock: function(a) {
                    var b = qlikview.currApp();
                    b.field(a).lock();
                },
                select: function(a, b, c, d) {
                    var e = qlikview.currApp();
                    e.field(a).select(b, c, d);
                },
                selectAll: function(a, b) {
                    var c = qlikview.currApp();
                    c.field(a).selectAll(b);
                },
                selectAlternative: function(a, b) {
                    console.log("field.selectAlternative", a);
                    var c = qlikview.currApp();
                    c.field(a).selectAlternative(b);
                },
                selectExcluded: function(a, b) {
                    var c = qlikview.currApp();
                    c.field(a).selectExcluded(b);
                },
                selectMatch: function(a, b, c) {
                    var d = qlikview.currApp();
                    d.field(a).selectMatch(b, c);
                },
                selectPossible: function(a, b) {
                    var c = qlikview.currApp();
                    c.field(a).selectPossible(b);
                },
                toggleSelect: function(a, b, c) {
                    var d = qlikview.currApp();
                    d.field(a).toggleSelect(b, c);
                },
                unlock: function(a) {
                    var b = qlikview.currApp();
                    b.field(a).unlock();
                }
            }
        };
    } ]);
});