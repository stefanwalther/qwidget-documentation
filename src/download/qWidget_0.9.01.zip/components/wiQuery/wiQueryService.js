define([ "angular", "qvangular", "qlikview" ], function(a, b, c) {
    "use strict";
    b.service("wiQueryService", [ "$q", "$timeout", function(a) {
        return {
            getGenericObject: function(b, d, e, f) {
                var g = a.defer(), h = c.currApp(), i = {};
                if (d) for (var j = 0; j < d.length; j++) {
                    console.log("expressions", d[j]);
                    var k;
                    "string" === d[j].type ? k = {
                        qStringExpression: d[j].expression
                    } : "value" === d[j].type && (k = {
                        qValueExpression: d[j].expression
                    }), i[d[j].target] = k;
                }
                if (f) for (var l = 0; l < f.length; l++) {
                    var m = {
                        qListObjectDef: {
                            qDef: {
                                qGrouping: "N",
                                qFieldDefs: [ f[l].field ]
                            },
                            qInitialDataFetch: [ {
                                qTop: 0,
                                qLeft: 0,
                                qHeight: 500,
                                qWidth: 1
                            } ]
                        }
                    };
                    i[f[l].target] = m;
                } else console.log("lists is empty");
                console.info("GenericObject Definition"), console.log("--Definition sent to engine: ", i);
                h.createGenericObject(i, function(a) {
                    console.info("createGenericObject"), console.log("--Response from engine: ", a), 
                    console.log("--Response from engine, field: ", a.selectedField.qListObject.qDimensionInfo.qFallbackTitle), 
                    delete b.result, b.result = a, console.log("--Scope result changed", b.result), 
                    g.resolve(a);
                });
                return g.promise;
            }
        };
    } ]);
});