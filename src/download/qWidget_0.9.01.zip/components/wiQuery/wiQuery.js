define([ "jquery", "qvangular", "./wiQueryService" ], function(a, b) {
    "use strict";
    b.directive("wiQuery", [ "$compile", "$timeout", "wiQueryService", function(a, b, c) {
        return {
            restrict: "E",
            replace: !0,
            scope: {},
            priority: 0,
            controller: [ "$scope", function() {} ],
            link: function(b, d, e) {
                var f, g = b.$watch(e.lists, function(a, b) {
                    console.info("List Watcher"), console.log("--newVal", a), console.log("--oldVal", b), 
                    void 0 !== a && a !== b && (console.log("--OK, lists have changed, get new data"), 
                    h());
                }), h = function() {
                    f && f.$destroy(), f = b.$new();
                    var a = f.$eval(e.expressions), d = f.$eval(e.hypercubes), g = f.$eval(e.lists);
                    c.getGenericObject(f, a, d, g).then(function() {
                        console.log("--getGenericObject completed, Use inner template"), i();
                    }).catch(function(a) {
                        console.log("An error has occured when fetching data from the engine ..."), console.err(a);
                    }).finally(function() {});
                }, i = function() {
                    console.info("Compile Data"), console.log("--updated scope, now containing the following field", f.result.selectedField.qListObject.qDimensionInfo.qFallbackTitle), 
                    console.log("--full local scope", f), a(d.contents())(f);
                };
                h(), b.$on("$destroy", function() {
                    console.info("wiQuery destroy"), d.remove(), g();
                });
            }
        };
    } ]);
});