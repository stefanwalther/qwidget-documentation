define([ "angular", "qvangular", "qlikview" ], function(a, b, c) {
    "use strict";
    b.service("wiSliderService", [ "$q", function(a) {
        return {
            getVariableContent: function(b) {
                var d = a.defer(), e = c.currApp();
                return e.variable.getContent(b).then(function(a) {
                    d.resolve(a);
                }), d.promise;
            },
            getVariableContents: function(b, c) {
                var d = a.defer(), e = [];
                return e[0] = this.getVariableContent(b), c && (e[1] = this.getVariableContent(c)), 
                console.log("--requests", e), a.all(e).then(function(a) {
                    console.log("reply from QS", a), d.resolve(a);
                }).catch(function(a) {
                    console.error(a);
                }).finally(function() {
                    console.log("finally");
                }), d.promise;
            }
        };
    } ]);
});