define([ "jquery", "qvangular", "qlikview", "objects.extension/base-controller", "angular", "./wiSliderService", "./external/jquery-ui-slider-pips.modified" ], function(a, b, c, d, e) {
    "use strict";
    b.directive("wiSlider", function() {
        var a = function(a, b) {
            var c = "wiSlider";
            b.wrap('<div class="' + c + '"></div>');
        };
        return {
            restrict: "E",
            template: "<div wi-slider-object></div>",
            replace: !0,
            link: a
        };
    });
    var f = [ "$scope", "wiSliderService", function(a) {
        a.defaultValue = void 0, a.defaultValueMin = void 0, a.defaultValueMax = void 0, 
        a.value = void 0, a.valueMin = void 0, a.valueMax = void 0, a.valuesInitialized = !1, 
        a.defaults = {
            min: 0,
            max: 100,
            step: 1,
            orientation: "horizontal",
            useDecimals: !1,
            range: !1,
            inits: "qs",
            ticks: {
                enabled: !0,
                labels: !1,
                first: "label",
                last: "label",
                rest: "pip",
                prefix: "",
                suffix: "",
                step: 1
            },
            tooltips: {
                enabled: !0,
                handle: !0,
                pips: !0,
                labels: !0
            }
        }, a.previousValue = {
            val: null,
            min: null,
            max: null
        };
    } ];
    b.directive("wiSliderObject", [ "$timeout", "wiSliderService", function(b, d) {
        console.log("wiSliderObject");
        var g = function() {
            function f(a, b) {
                return b ? parseFloat(a) : parseInt(a);
            }
            function g(a) {
                return a === !0 || "true" === a;
            }
            function h(a, b) {
                return a === !0 || "true" === a ? !0 : a === !1 || "false" === a ? !1 : b;
            }
            var i = function(i, j, k) {
                function l() {
                    console.log("--inside init"), q.range || e.isDefined(i.defaultValue) || (i.defaultValue = f((q.max - -1 * q.min) / 2, s)), 
                    !q.range || e.isDefined(i.defaultValueMin) || e.isDefined(i.defaultValueMax) || (i.defaultValueMin = f(q.max - (q.max - -1 * q.min) / 3 * 2, s), 
                    i.defaultValueMax = f(q.max - (q.max - -1 * q.min) / 3 * 1, s), console.log("defaultValueMin", i.defaultValueMin), 
                    console.log("defaultValueMax", i.defaultValueMax)), console.log("--:init:slider options", q), 
                    j.slider(q), m(), q.ticks.enabled && j.slider("pips", q.ticks), q.tooltips.enabled && j.slider("float", q.tooltips);
                }
                function m() {
                    q.range ? j.slider("values", [ i.valueMin || i.defaultValueMin, i.valueMax || i.defaultValueMax ]) : j.slider("value", i.value || i.defaultValue);
                }
                function n() {
                    q = {
                        min: e.isDefined(k.min) ? f(k.min, s) : i.defaults.min,
                        max: e.isDefined(k.max) ? f(k.max, s) : i.defaults.max,
                        step: e.isDefined(k.step) ? f(k.step, s) : i.defaults.step,
                        orientation: "vertical" === k.orientation ? "vertical" : i.defaults.orientation,
                        range: e.isDefined(k.range) ? g(k.range) : i.defaults.range,
                        useDecimals: e.isDefined(k.useDecimals) ? g(k.useDecimals) : i.defaults.useDecimals,
                        ticks: {
                            enabled: e.isDefined(k.ticks) ? h(i.$eval(k.ticks), i.defaults.ticks.enabled) : i.defaults.ticks.enabled,
                            labels: e.isDefined(k.ticksLabels) ? i.$eval(k.ticksLabels) : i.defaults.ticks.labels,
                            first: e.isDefined(k.ticksFirst) ? h(k.ticksFirst, i.defaults.ticks.first) : i.defaults.ticks.first,
                            last: e.isDefined(k.ticksLast) ? h(k.ticksLast, i.defaults.ticks.first) : i.defaults.ticks.last,
                            rest: e.isDefined(k.ticksRest) ? h(k.ticksRest, i.defaults.ticks.first) : i.defaults.ticks.rest,
                            prefix: e.isDefined(k.ticksPrefix) ? k.ticksPrefix : i.defaults.ticks.prefix,
                            suffix: e.isDefined(k.ticksSuffix) ? k.ticksSuffix : i.defaults.ticks.suffix,
                            step: e.isDefined(k.ticksStep) ? f(k.ticksStep, s) : i.defaults.ticks.step
                        },
                        tooltips: {
                            enabled: !0,
                            handle: e.isDefined(k.tooltipsHandle) ? i.$eval(k.tooltipsHandle) : i.defaults.tooltips.handle,
                            pips: e.isDefined(k.tooltipsPips) ? i.$eval(k.tooltipsPips) : i.defaults.tooltips.pips,
                            labels: e.isDefined(k.tooltipsLabels) ? i.$eval(k.tooltipsLabels) : i.defaults.tooltips.labels,
                            prefix: e.isDefined(k.tooltipsPrefix) ? k.tooltipsPrefix : i.defaults.tooltips.prefix,
                            suffix: e.isDefined(k.tooltipsSuffix) ? k.tooltipsSuffix : i.defaults.tooltips.suffix
                        }
                    }, "vertical" === q.orientation && (q.tooltips.enabled = !1), _.isNumber(q.step) && 0 !== q.step || (q.step = i.defaults.step), 
                    _.isString(q.ticks.first) && q.ticks.first.replace("tick", "pip"), _.isString(q.ticks.last) && q.ticks.last.replace("tick", "pip"), 
                    _.isString(q.ticks.rest) && q.ticks.rest.replace("tick", "pip");
                }
                function o(a) {
                    var b = c.currApp();
                    _.isArray(a) ? (console.log("updateQsVariable:range", i.previousValue), i.previousValue.min !== a[0] && (console.log("--update min"), 
                    b.variable.setContent(i.bindQsMin, "=(" + a[0] + ")").then(function(b) {
                        console.log("--qsReturn:min", b), b && b.qReturn && (i.previousValue.min = a[0]);
                    }).catch(function(a) {
                        console.error(a);
                    })), i.previousValue.max !== a[1] && (console.log("--update max"), b.variable.setContent(i.bindQsMax, "=(" + a[1] + ")").then(function(b) {
                        console.log("--qsReturn:max", b), b && b.qReturn && (i.previousValue.max = a[1]);
                    }).catch(function(a) {
                        console.error(a);
                    }))) : (console.log("updateQsVariable:single value", i.previousValue.val), i.previousValue.val !== a && (console.log("--update single"), 
                    b.variable.setContent(i.bindQs, "=(" + a + ")").then(function(b) {
                        console.log("--qsReturn:val", b), b && b.qReturn && (i.previousValue.val = a);
                    }).catch(function(a) {
                        console.error(a);
                    })));
                }
                function p() {
                    console.info("wiSlider.$destroy"), j.slider("destroy"), _.each(r, function(a) {
                        e.isFunction(a) && a();
                    });
                }
                var q = {}, r = [], s = !1;
                if (n(), r.push(b(function() {
                    l();
                }, 0, !0)), !i.valuesInitialized && (q.range && e.isDefined(k.bindQsMin) && e.isDefined(k.bindQsMax) || !q.range && e.isDefined(k.bindQs))) {
                    console.log("OK, lets retrieve the values ...");
                    var t = q.range ? k.bindQsMin : k.bindQs, u = q.range ? k.bindQsMax : void 0;
                    d.getVariableContents(t, u).then(function(a) {
                        var b, c;
                        a[0] && a[0].qContent && a[0].qContent.qIsNum && (b = f(a[0].qContent.qString, s)), 
                        a[1] && a[1].qContent && a[1].qContent.qIsNum && (c = f(a[1].qContent.qString, s)), 
                        q.range ? (i.valueMin = b, i.valueMax = c) : i.value = b, console.log("OK, lets set the slider values ..."), 
                        m();
                    }).catch(function() {
                        e.noop();
                    }).finally(function() {
                        i.valuesInitialized = !0;
                    });
                }
                j.bind("slidechange", function(a, b) {
                    console.log("--slide event", b.values || b.value), b.values ? (i.bindLocalMin && (i.bindLocalMin = b.values[0]), 
                    i.bindLocalMax && (i.bindLocalMax = b.values[1])) : i.bindLocal && (i.bindLocal = b.value), 
                    i.valuesInitialized && o(b.values || b.value);
                }), a(window).resize(function() {
                    console.log("window.resize, so render again"), l();
                }), j.bind("$destroy", p);
            };
            return i;
        };
        return {
            compile: g,
            restrict: "AE",
            controller: f,
            scope: {
                bindLocal: "=",
                bindLocalMin: "=",
                bindLocalMax: "=",
                bindQs: "@",
                bindQsMin: "@",
                bindQsMax: "@",
                inits: "@",
                useDecimals: "@",
                ticks: "@",
                ticksLabels: "@",
                ticksFirst: "@",
                ticksLast: "@",
                ticksRest: "@",
                ticksPrefix: "@",
                ticksSuffix: "@",
                ticksStep: "@",
                tooltips: "@",
                tooltipsHandle: "@",
                tooltipsPips: "@",
                tooltipsLabels: "@",
                tooltipsPrefix: "@",
                tooltipsSuffix: "@"
            }
        };
    } ]);
});