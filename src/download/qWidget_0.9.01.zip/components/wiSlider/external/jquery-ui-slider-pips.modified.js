!function(a) {
    "use strict";
    var b = {
        pips: function(b) {
            function c(b) {
                var c = a(b).data("value"), d = a(e.element), f = 0;
                if (!0 === e.options.range) {
                    var g = d.slider("values");
                    g[0] === g[1] ? c < g[0] ? d.slider("values", [ c, g[1] ]) : (d.slider("values", [ g[0], c ]), 
                    f = 1) : Math.abs(g[0] - c) === Math.abs(g[1] - c) ? d.slider("values", [ c, c ]) : Math.abs(g[0] - c) < Math.abs(g[1] - c) ? d.slider("values", [ c, g[1] ]) : (d.slider("values", [ g[0], c ]), 
                    f = 1);
                } else d.slider("value", c);
            }
            function d(a) {
                var b, c, d = a, i = "ui-slider-pip", j = "";
                "first" === a ? d = 0 : "last" === a && (d = g);
                var k = e.options.min + e.options.step * d, l = k.toString().replace(".", "-");
                b = h.labels ? h.labels[d] : k, "undefined" == typeof b && (b = ""), "first" === a ? (c = "0%", 
                i += " ui-slider-pip-first", i += "label" === h.first ? " ui-slider-pip-label" : "", 
                i += !1 === h.first ? " ui-slider-pip-hide" : "") : "last" === a ? (c = "100%", 
                i += " ui-slider-pip-last", i += "label" === h.last ? " ui-slider-pip-label" : "", 
                i += !1 === h.last ? " ui-slider-pip-hide" : "") : (c = (100 / g * a).toFixed(4) + "%", 
                i += "label" === h.rest ? " ui-slider-pip-label" : "", i += !1 === h.rest ? " ui-slider-pip-hide" : ""), 
                i += " ui-slider-pip-" + l, j = "horizontal" === e.options.orientation ? "left: " + c : "bottom: " + c, 
                f += '<span class="' + i + '" style="' + j + '"><span class="ui-slider-line"></span><span class="ui-slider-label" data-value="' + k + '">' + h.formatLabel(b) + "</span></span>";
            }
            var e = this, f = "", g = (e.options.max - e.options.min) / e.options.step, h = {
                first: "label",
                last: "label",
                rest: "pip",
                labels: !1,
                prefix: "",
                suffix: "",
                step: g > 100 ? Math.floor(.05 * g) : 1,
                formatLabel: function(a) {
                    try {
                        return this.prefix + a + this.suffix;
                    } catch (b) {
                        return console.error(b), console.log("--Exception with the following value: ", a), 
                        " ";
                    }
                }
            };
            a.extend(h, b), e.options.pipStep = h.step, e.element.addClass("ui-slider-pips").find(".ui-slider-pip").remove(), 
            e.options.pipStep = e.options.pipStep, d("first");
            for (var i = 1; g > i; i++) 0 === i % e.options.pipStep && d(i);
            d("last"), e.element.append(f), e.element.on("mouseup", ".ui-slider-label", function() {
                c(this);
            });
        }
    };
    a.extend(!0, a.ui.slider.prototype, b);
}(jQuery), function(a) {
    "use strict";
    var b = {
        "float": function(b) {
            var c, d, e = this, f = [], g = {
                handle: !0,
                pips: !1,
                labels: !1,
                prefix: "",
                suffix: "",
                event: "slidechange slide",
                formatLabel: function(a) {
                    return this.prefix + a + this.suffix;
                }
            };
            a.extend(g, b), e.options.value < e.options.min && (e.options.value = e.options.min), 
            e.options.value > e.options.max && (e.options.value = e.options.max), e.options.values && (e.options.values[0] < e.options.min && (e.options.values[0] = e.options.min), 
            e.options.values[1] < e.options.min && (e.options.values[1] = e.options.min), e.options.values[0] > e.options.max && (e.options.values[0] = e.options.max), 
            e.options.values[1] > e.options.max && (e.options.values[1] = e.options.max)), e.element.addClass("ui-slider-float").find(".ui-slider-tip, .ui-slider-tip-label").remove(), 
            g.handle && (e.options.values ? (g.labels ? (f[0] = g.labels[e.options.values[0] - e.options.min], 
            f[1] = g.labels[e.options.values[1] - e.options.min], "undefined" == typeof f[0] && (f[0] = e.options.values[0]), 
            "undefined" == typeof f[1] && (f[1] = e.options.values[1])) : (f[0] = e.options.values[0], 
            f[1] = e.options.values[1]), c = [ a('<span class="ui-slider-tip">' + g.formatLabel(f[0]) + "</span>"), a('<span class="ui-slider-tip">' + g.formatLabel(f[1]) + "</span>") ]) : (g.labels ? (d = g.labels[e.options.value - e.options.min], 
            "undefined" == typeof d && (d = e.options.value)) : d = e.options.value, c = a('<span class="ui-slider-tip">' + g.formatLabel(d) + "</span>")), 
            e.element.find(".ui-slider-handle").each(function(b, d) {
                a(d).append(c[b]);
            })), g.pips && e.element.find(".ui-slider-label").each(function(b, c) {
                var d = a(c), e = d.data("value"), f = d.data("value");
                "undefined" != typeof g.labels[e] && (f = g.labels[e]), a('<span class="ui-slider-tip-label">' + g.formatLabel(f) + "</span>").insertAfter(d);
            }), "slide" !== g.event && "slidechange" !== g.event && "slide slidechange" !== g.event && "slidechange slide" !== g.event && (g.event = "slidechange slide"), 
            e.element.on(g.event, function(b, c) {
                var d;
                g.labels ? (d = g.labels[c.value - e.options.min], "undefined" == typeof d && (d = c.value)) : d = c.value, 
                a(c.handle).find(".ui-slider-tip").css("position", "fixed").css("top", a(c.handle).offset().top - 30).css("left", a(c.handle).offset().left + 8.85).html(g.formatLabel(d));
            }), e.element.on("slidestop", function(b, c) {
                a(c.handle).find(".ui-slider-tip").css("position", "fixed").css("top", a(c.handle).offset().top - 30).css("left", a(c.handle).offset().left + 8.85).show();
            }), e.element.on("slide", function(b, c) {
                a(c.handle).find(".ui-slider-tip").hide();
            });
        }
    };
    a.extend(!0, a.ui.slider.prototype, b);
}(jQuery);