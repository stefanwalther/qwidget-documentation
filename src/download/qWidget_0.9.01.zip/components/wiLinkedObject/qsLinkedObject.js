define([ "jquery", "qvangular", "angular", "objects.extension/base-controller", "qlikview", "text!./qsLinkedObject.DummyImage.ng.html" ], function(a, b, c, d, e, f) {
    "use strict";
    b.directive("qsLinkedObject", [ "$timeout", "$compile", function(b, d) {
        return {
            restrict: "E",
            scope: !0,
            replace: !0,
            transclude: !0,
            link: function(g, h) {
                function i() {
                    if (console.log("bindObject"), console.log("--$scope.dataBoundId", g.dataBoundId), 
                    g.inEditMode) {
                        console.log("--dummy object"), h.empty();
                        var i = d(f)(g);
                        h.append(i);
                    } else if (console.log("--full object"), void 0 !== g.object && g.dataBoundId !== g.object) {
                        console.log("--Bind the following object: ", g.object);
                        var k = a(document.createElement("div"));
                        k.css("height", "100%"), k.css("width", "100%"), k.attr("data-qvid", g.object);
                        {
                            j.getObject(k, g.object).then(function() {
                                b(function() {
                                    g.dataBoundId = g.object;
                                }, 100).then(function() {
                                    k.find("*").each(function() {
                                        a(this).addClass("wi-nobs");
                                    });
                                }).then(function() {
                                    h.empty(), h.append(k), e.resize();
                                });
                            }).catch(function(a) {
                                console.error("Error from the engine", a), c.noop();
                            }).finally(function() {
                                c.noop();
                            });
                        }
                    }
                }
                if (console.log("qsLinkedObjectScope", g), h.addClass("qWidget_qsLinkedObject"), 
                g.getElementDimensions = function() {
                    return g.inEditMode ? {
                        h: h.closest(".wiView_htmlContainer").height,
                        w: h.closest(".wiView_htmlContainer").width()
                    } : {
                        h: h.closest(".cell").height,
                        w: h.closest(".cell").width()
                    };
                }, g.$watch(g.getElementDimensions, function(a, b) {
                    void 0 !== a && a !== b && e.resize();
                }, !0), g.$watch("inEditMode", function() {
                    i();
                }), h.on("resize", function() {
                    g.$apply();
                }), void 0 !== g.object) {
                    var j = e.currApp();
                    _.contains([ "random", "randomAny", "randomChart" ], g.object) ? c.noop() : i();
                }
                g.$on("$destroy", function() {
                    console.log("qsLinkedObject:destroy", g.object), h.remove(), h.off();
                });
            }
        };
    } ]);
});