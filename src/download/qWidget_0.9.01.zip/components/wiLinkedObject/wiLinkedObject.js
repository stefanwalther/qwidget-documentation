define([ "jquery", "qvangular", "qlikview", "angular", "objects.extension/base-controller", "text!./wiLinkedObject.ng.html", "./qsLinkedObject" ], function(a, b, c, d, e, f) {
    "use strict";
    b.directive("wiLinkedObject", function() {
        return {
            restrict: "AE",
            replace: !0,
            template: f,
            scope: !0,
            link: function(a, b, c) {
                a.type = "qs", a.isSelf = function() {
                    return a.object === a.$parent.layout.qInfo.qId;
                }, a.object = c.object, a.height = d.isDefined(c.height) ? c.height : "100%", a.width = d.isDefined(c.width) ? c.width : "100%", 
                a.inEditMode = a.Main.showEditor;
            }
        };
    });
});