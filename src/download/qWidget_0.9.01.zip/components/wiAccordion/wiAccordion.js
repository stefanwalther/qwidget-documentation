define([ "jquery", "qvangular", "objects.extension/base-controller", "angular", "./../../modules/utils/wiUtils", "text!./../wiBootstrap/css/wiBootstrap.css" ], function(a, b, c, d, e, f) {
    "use strict";
    e.addStyleToHeader("wiBootstrap", f);
    c.extend({
        init: function() {}
    });
    b.directive("wiAccordion", function() {
        return {
            restrict: "E",
            transclude: !0,
            scope: {},
            compile: function(b, c, d) {
                return function(c) {
                    d(c.$parent, function(c) {
                        var d = a(document.createElement("div"));
                        d.addClass("wi-bs"), d.append(c), b.append(d);
                    });
                };
            }
        };
    }), b.directive("bla", function() {
        return {
            restrict: "EA",
            transclude: !0,
            replace: !0,
            scope: {
                type: "@"
            },
            controller: [ "$scope", TabsetController ],
            templateUrl: "/extensions/qWidget/components/wiTab/template/tabset.html",
            link: function(a, b, c) {
                console.log("vertical:", a.$parent.$eval(c.vertical)), a.vertical = d.isDefined(c.vertical) ? a.$parent.$eval(c.vertical) : !1, 
                a.justified = d.isDefined(c.justified) ? a.$parent.$eval(c.justified) : !1;
            }
        };
    });
});