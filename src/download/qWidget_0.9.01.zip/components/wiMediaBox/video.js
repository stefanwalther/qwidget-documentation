!function() {
    function m() {
        return function() {};
    }
    function p(a) {
        return function() {
            return this[a];
        };
    }
    function s(a) {
        return function() {
            return a;
        };
    }
    function u(a, b, c) {
        if ("string" == typeof a) {
            if (0 === a.indexOf("#") && (a = a.slice(1)), u.xa[a]) return u.xa[a];
            a = u.w(a);
        }
        if (!a || !a.nodeName) throw new TypeError("The element or ID supplied is not valid. (videojs)");
        return a.player || new u.s(a, b, c);
    }
    function D(a) {
        a.u("vjs-lock-showing");
    }
    function E(a, c, d, e) {
        return d !== b ? (a.a.style[c] = -1 !== ("" + d).indexOf("%") || -1 !== ("" + d).indexOf("px") ? d : "auto" === d ? "" : d + "px", 
        e || a.j("resize"), a) : a.a ? (d = a.a.style[c], e = d.indexOf("px"), -1 !== e ? parseInt(d.slice(0, e), 10) : parseInt(a.a["offset" + u.$(c)], 10)) : 0;
    }
    function F(a, b) {
        var c, d, e, f;
        return c = a.a, d = u.ad(c), f = e = c.offsetWidth, c = a.handle, a.g.Cd ? (f = d.top, 
        d = b.changedTouches ? b.changedTouches[0].pageY : b.pageY, c && (c = c.w().offsetHeight, 
        f += c / 2, e -= c), Math.max(0, Math.min(1, (f - d + e) / e))) : (e = d.left, d = b.changedTouches ? b.changedTouches[0].pageX : b.pageX, 
        c && (c = c.w().offsetWidth, e += c / 2, f -= c), Math.max(0, Math.min(1, (d - e) / f)));
    }
    function ca(a, b) {
        a.Z(b), b.d("click", u.bind(a, function() {
            D(this);
        }));
    }
    function H(a) {
        a.pa = f, a.wa.n("vjs-lock-showing"), a.a.setAttribute("aria-pressed", f), a.I && 0 < a.I.length && a.I[0].w().focus();
    }
    function G(a) {
        a.pa = l, D(a.wa), a.a.setAttribute("aria-pressed", l);
    }
    function da(a) {
        var b = {
            sources: [],
            tracks: []
        };
        if (u.k.B(b, u.xb(a)), a.hasChildNodes()) {
            var c, d, e, f;
            for (a = a.childNodes, e = 0, f = a.length; f > e; e++) c = a[e], d = c.nodeName.toLowerCase(), 
            "source" === d ? b.sources.push(u.xb(c)) : "track" === d && b.tracks.push(u.xb(c));
        }
        return b;
    }
    function I(a, b, c) {
        a.h ? (a.aa = l, a.h.D(), a.Eb && (a.Eb = l, clearInterval(a.Ra)), a.Fb && J(a), 
        a.h = l) : "Html5" !== b && a.M && (u.l.jc(a.M), a.M = h), a.ia = b, a.aa = l;
        var d = u.k.B({
            source: c,
            parentEl: a.a
        }, a.g[b.toLowerCase()]);
        c && (c.src == a.v.src && 0 < a.v.currentTime && (d.startTime = a.v.currentTime), 
        a.v.src = c.src), a.h = new window.videojs[b](a, d), a.h.L(function() {
            if (this.b.Ua(), !this.m.progressEvents) {
                var a = this.b;
                a.Eb = f, a.Ra = setInterval(u.bind(a, function() {
                    this.v.lb < this.buffered().end(0) ? this.j("progress") : 1 == this.Ja() && (clearInterval(this.Ra), 
                    this.j("progress"));
                }), 500), a.h.U("progress", function() {
                    this.m.progressEvents = f;
                    var a = this.b;
                    a.Eb = l, clearInterval(a.Ra);
                });
            }
            this.m.timeupdateEvents || (a = this.b, a.Fb = f, a.d("play", a.Cc), a.d("pause", a.za), 
            a.h.U("timeupdate", function() {
                this.m.timeupdateEvents = f, J(this.b);
            }));
        });
    }
    function J(a) {
        a.Fb = l, a.za(), a.o("play", a.Cc), a.o("pause", a.za);
    }
    function L(a, b, c) {
        if (a.h && !a.h.aa) a.h.L(function() {
            this[b](c);
        }); else try {
            a.h[b](c);
        } catch (d) {
            throw u.log(d), d;
        }
    }
    function K(a, c) {
        if (a.h && a.h.aa) try {
            return a.h[c]();
        } catch (d) {
            throw a.h[c] === b ? u.log("Video.js: " + c + " method not defined for " + a.ia + " playback technology.", d) : "TypeError" == d.name ? (u.log("Video.js: " + c + " unavailable on " + a.ia + " playback technology element.", d), 
            a.h.aa = l) : u.log(d), d;
        }
    }
    function M(a) {
        a.cd = l, u.o(document, "keydown", a.lc), document.documentElement.style.overflow = a.Yc, 
        u.u(document.body, "vjs-full-window"), a.j("exitFullWindow");
    }
    function ea() {
        var a = u.media.Va[i];
        return function() {
            throw Error('The "' + a + "\" method is not available on the playback technology's API");
        };
    }
    function fa() {
        var a = R[T], b = a.charAt(0).toUpperCase() + a.slice(1);
        Q["set" + b] = function(b) {
            return this.a.vjs_setProperty(a, b);
        };
    }
    function U(a) {
        Q[a] = function() {
            return this.a.vjs_getProperty(a);
        };
    }
    function V(a) {
        return a.Aa = a.Aa || [], a.Aa;
    }
    function W(a, b, c) {
        for (var d, e, f = a.Aa, g = 0, h = f.length; h > g; g++) d = f[g], d.id() === b ? (d.show(), 
        e = d) : c && d.J() == c && 0 < d.mode() && d.disable();
        (b = e ? e.J() : c ? c : l) && a.j(b + "trackchange");
    }
    function X(a) {
        0 === a.ha && a.load(), 0 === a.ga && (a.b.d("timeupdate", u.bind(a, a.update, a.Q)), 
        a.b.d("ended", u.bind(a, a.reset, a.Q)), ("captions" === a.A || "subtitles" === a.A) && a.b.V.textTrackDisplay.Z(a));
    }
    function Y(a) {
        var b = a.split(":");
        a = 0;
        var c, d, e;
        return 3 == b.length ? (c = b[0], d = b[1], b = b[2]) : (c = 0, d = b[0], b = b[1]), 
        b = b.split(/\s+/), b = b.splice(0, 1)[0], b = b.split(/\.|,/), e = parseFloat(b[1]), 
        b = b[0], a += 3600 * parseFloat(c), a += 60 * parseFloat(d), a += parseFloat(b), 
        e && (a += e / 1e3), a;
    }
    function $(a, c) {
        var d = a.split("."), e = ga;
        !(d[0] in e) && e.execScript && e.execScript("var " + d[0]);
        for (var f; d.length && (f = d.shift()); ) d.length || c === b ? e = e[f] ? e[f] : e[f] = {} : e[f] = c;
    }
    var b = void 0, f = !0, h = null, l = !1, t;
    document.createElement("video"), document.createElement("audio"), document.createElement("track");
    var v = u;
    window.Td = window.Ud = u, u.Tb = "4.3", u.Fc = "https:" == document.location.protocol ? "https://" : "http://", 
    u.options = {
        techOrder: [ "html5", "flash" ],
        html5: {},
        flash: {},
        width: 300,
        height: 150,
        defaultVolume: 0,
        children: {
            mediaLoader: {},
            posterImage: {},
            textTrackDisplay: {},
            loadingSpinner: {},
            bigPlayButton: {},
            controlBar: {}
        },
        notSupportedMessage: 'Sorry, no compatible source and playback technology were found for this video. Try using another browser like <a href="http://bit.ly/ccMUEC">Chrome</a> or download the latest <a href="http://adobe.ly/mwfN1">Adobe Flash Player</a>.'
    }, "GENERATED_CDN_VSN" !== u.Tb && (v.options.flash.swf = u.Fc + "vjs.zencdn.net/" + u.Tb + "/video-js.swf"), 
    u.xa = {}, u.la = u.CoreObject = m(), u.la.extend = function(a) {
        var b, c;
        a = a || {}, b = a.init || a.i || this.prototype.init || this.prototype.i || m(), 
        c = function() {
            b.apply(this, arguments);
        }, c.prototype = u.k.create(this.prototype), c.prototype.constructor = c, c.extend = u.la.extend, 
        c.create = u.la.create;
        for (var d in a) a.hasOwnProperty(d) && (c.prototype[d] = a[d]);
        return c;
    }, u.la.create = function() {
        var a = u.k.create(this.prototype);
        return this.apply(a, arguments), a;
    }, u.d = function(a, b, c) {
        var d = u.getData(a);
        d.z || (d.z = {}), d.z[b] || (d.z[b] = []), c.t || (c.t = u.t++), d.z[b].push(c), 
        d.W || (d.disabled = l, d.W = function(b) {
            if (!d.disabled) {
                b = u.kc(b);
                var c = d.z[b.type];
                if (c) for (var c = c.slice(0), e = 0, f = c.length; f > e && !b.pc(); e++) c[e].call(a, b);
            }
        }), 1 == d.z[b].length && (document.addEventListener ? a.addEventListener(b, d.W, l) : document.attachEvent && a.attachEvent("on" + b, d.W));
    }, u.o = function(a, b, c) {
        if (u.oc(a)) {
            var d = u.getData(a);
            if (d.z) if (b) {
                var e = d.z[b];
                if (e) {
                    if (c) {
                        if (c.t) for (d = 0; d < e.length; d++) e[d].t === c.t && e.splice(d--, 1);
                    } else d.z[b] = [];
                    u.gc(a, b);
                }
            } else for (e in d.z) b = e, d.z[b] = [], u.gc(a, b);
        }
    }, u.gc = function(a, b) {
        var c = u.getData(a);
        0 === c.z[b].length && (delete c.z[b], document.removeEventListener ? a.removeEventListener(b, c.W, l) : document.detachEvent && a.detachEvent("on" + b, c.W)), 
        u.Bb(c.z) && (delete c.z, delete c.W, delete c.disabled), u.Bb(c) && u.vc(a);
    }, u.kc = function(a) {
        function b() {
            return f;
        }
        function c() {
            return l;
        }
        if (!a || !a.Cb) {
            var d = a || window.event;
            a = {};
            for (var e in d) "layerX" !== e && "layerY" !== e && (a[e] = d[e]);
            if (a.target || (a.target = a.srcElement || document), a.relatedTarget = a.fromElement === a.target ? a.toElement : a.fromElement, 
            a.preventDefault = function() {
                d.preventDefault && d.preventDefault(), a.returnValue = l, a.Ab = b;
            }, a.Ab = c, a.stopPropagation = function() {
                d.stopPropagation && d.stopPropagation(), a.cancelBubble = f, a.Cb = b;
            }, a.Cb = c, a.stopImmediatePropagation = function() {
                d.stopImmediatePropagation && d.stopImmediatePropagation(), a.pc = b, a.stopPropagation();
            }, a.pc = c, a.clientX != h) {
                e = document.documentElement;
                var g = document.body;
                a.pageX = a.clientX + (e && e.scrollLeft || g && g.scrollLeft || 0) - (e && e.clientLeft || g && g.clientLeft || 0), 
                a.pageY = a.clientY + (e && e.scrollTop || g && g.scrollTop || 0) - (e && e.clientTop || g && g.clientTop || 0);
            }
            a.which = a.charCode || a.keyCode, a.button != h && (a.button = 1 & a.button ? 0 : 4 & a.button ? 1 : 2 & a.button ? 2 : 0);
        }
        return a;
    }, u.j = function(a, b) {
        var c = u.oc(a) ? u.getData(a) : {}, d = a.parentNode || a.ownerDocument;
        return "string" == typeof b && (b = {
            type: b,
            target: a
        }), b = u.kc(b), c.W && c.W.call(a, b), d && !b.Cb() && b.bubbles !== l ? u.j(d, b) : d || b.Ab() || (c = u.getData(b.target), 
        !b.target[b.type]) || (c.disabled = f, "function" == typeof b.target[b.type] && b.target[b.type](), 
        c.disabled = l), !b.Ab();
    }, u.U = function(a, b, c) {
        function d() {
            u.o(a, b, d), c.apply(this, arguments);
        }
        d.t = c.t = c.t || u.t++, u.d(a, b, d);
    };
    var w = Object.prototype.hasOwnProperty;
    u.e = function(a, b) {
        var c, d;
        c = document.createElement(a || "div");
        for (d in b) w.call(b, d) && (-1 !== d.indexOf("aria-") || "role" == d ? c.setAttribute(d, b[d]) : c[d] = b[d]);
        return c;
    }, u.$ = function(a) {
        return a.charAt(0).toUpperCase() + a.slice(1);
    }, u.k = {}, u.k.create = Object.create || function(a) {
        function b() {}
        return b.prototype = a, new b();
    }, u.k.ua = function(a, b, c) {
        for (var d in a) w.call(a, d) && b.call(c || this, d, a[d]);
    }, u.k.B = function(a, b) {
        if (!b) return a;
        for (var c in b) w.call(b, c) && (a[c] = b[c]);
        return a;
    }, u.k.ic = function(a, b) {
        var c, d, e;
        a = u.k.copy(a);
        for (c in b) w.call(b, c) && (d = a[c], e = b[c], a[c] = u.k.qc(d) && u.k.qc(e) ? u.k.ic(d, e) : b[c]);
        return a;
    }, u.k.copy = function(a) {
        return u.k.B({}, a);
    }, u.k.qc = function(a) {
        return !!a && "object" == typeof a && "[object Object]" === a.toString() && a.constructor === Object;
    }, u.bind = function(a, b, c) {
        function d() {
            return b.apply(a, arguments);
        }
        return b.t || (b.t = u.t++), d.t = c ? c + "_" + b.t : b.t, d;
    }, u.ra = {}, u.t = 1, u.expando = "vdata" + new Date().getTime(), u.getData = function(a) {
        var b = a[u.expando];
        return b || (b = a[u.expando] = u.t++, u.ra[b] = {}), u.ra[b];
    }, u.oc = function(a) {
        return a = a[u.expando], !(!a || u.Bb(u.ra[a]));
    }, u.vc = function(a) {
        var b = a[u.expando];
        if (b) {
            delete u.ra[b];
            try {
                delete a[u.expando];
            } catch (c) {
                a.removeAttribute ? a.removeAttribute(u.expando) : a[u.expando] = h;
            }
        }
    }, u.Bb = function(a) {
        for (var b in a) if (a[b] !== h) return l;
        return f;
    }, u.n = function(a, b) {
        -1 == (" " + a.className + " ").indexOf(" " + b + " ") && (a.className = "" === a.className ? b : a.className + " " + b);
    }, u.u = function(a, b) {
        var c, d;
        if (-1 != a.className.indexOf(b)) {
            for (c = a.className.split(" "), d = c.length - 1; d >= 0; d--) c[d] === b && c.splice(d, 1);
            a.className = c.join(" ");
        }
    }, u.na = u.e("video"), u.F = navigator.userAgent, u.Mc = /iPhone/i.test(u.F), u.Lc = /iPad/i.test(u.F), 
    u.Nc = /iPod/i.test(u.F), u.Kc = u.Mc || u.Lc || u.Nc;
    var aa = u, x, y = u.F.match(/OS (\d+)_/i);
    x = y && y[1] ? y[1] : b, aa.Fd = x, u.Ic = /Android/i.test(u.F);
    var ba = u, z, A = u.F.match(/Android (\d+)(?:\.(\d+))?(?:\.(\d+))*/i), B, C;
    A ? (B = A[1] && parseFloat(A[1]), C = A[2] && parseFloat(A[2]), z = B && C ? parseFloat(A[1] + "." + A[2]) : B ? B : h) : z = h, 
    ba.Gc = z, u.Oc = u.Ic && /webkit/i.test(u.F) && 2.3 > u.Gc, u.Jc = /Firefox/i.test(u.F), 
    u.Gd = /Chrome/i.test(u.F), u.ac = !!("ontouchstart" in window || window.Hc && document instanceof window.Hc), 
    u.xb = function(a) {
        var b, c, d, e;
        if (b = {}, a && a.attributes && 0 < a.attributes.length) {
            c = a.attributes;
            for (var g = c.length - 1; g >= 0; g--) d = c[g].name, e = c[g].value, ("boolean" == typeof a[d] || -1 !== ",autoplay,controls,loop,muted,default,".indexOf("," + d + ",")) && (e = e !== h ? f : l), 
            b[d] = e;
        }
        return b;
    }, u.Kd = function(a, b) {
        var c = "";
        return document.defaultView && document.defaultView.getComputedStyle ? c = document.defaultView.getComputedStyle(a, "").getPropertyValue(b) : a.currentStyle && (c = a["client" + b.substr(0, 1).toUpperCase() + b.substr(1)] + "px"), 
        c;
    }, u.zb = function(a, b) {
        b.firstChild ? b.insertBefore(a, b.firstChild) : b.appendChild(a);
    }, u.Pb = {}, u.w = function(a) {
        return 0 === a.indexOf("#") && (a = a.slice(1)), document.getElementById(a);
    }, u.La = function(a, b) {
        b = b || a;
        var c = Math.floor(a % 60), d = Math.floor(a / 60 % 60), e = Math.floor(a / 3600), f = Math.floor(b / 60 % 60), g = Math.floor(b / 3600);
        return (isNaN(a) || 1/0 === a) && (e = d = c = "-"), e = e > 0 || g > 0 ? e + ":" : "", 
        e + (((e || f >= 10) && 10 > d ? "0" + d : d) + ":") + (10 > c ? "0" + c : c);
    }, u.Tc = function() {
        document.body.focus(), document.onselectstart = s(l);
    }, u.Bd = function() {
        document.onselectstart = s(f);
    }, u.trim = function(a) {
        return (a + "").replace(/^\s+|\s+$/g, "");
    }, u.round = function(a, b) {
        return b || (b = 0), Math.round(a * Math.pow(10, b)) / Math.pow(10, b);
    }, u.tb = function(a, b) {
        return {
            length: 1,
            start: function() {
                return a;
            },
            end: function() {
                return b;
            }
        };
    }, u.get = function(a, b, c) {
        var d, e;
        "undefined" == typeof XMLHttpRequest && (window.XMLHttpRequest = function() {
            try {
                return new window.ActiveXObject("Msxml2.XMLHTTP.6.0");
            } catch (a) {}
            try {
                return new window.ActiveXObject("Msxml2.XMLHTTP.3.0");
            } catch (b) {}
            try {
                return new window.ActiveXObject("Msxml2.XMLHTTP");
            } catch (c) {}
            throw Error("This browser does not support XMLHttpRequest.");
        }), e = new XMLHttpRequest();
        try {
            e.open("GET", a);
        } catch (f) {
            c(f);
        }
        d = 0 === a.indexOf("file:") || 0 === window.location.href.indexOf("file:") && -1 === a.indexOf("http"), 
        e.onreadystatechange = function() {
            4 === e.readyState && (200 === e.status || d && 0 === e.status ? b(e.responseText) : c && c());
        };
        try {
            e.send();
        } catch (g) {
            c && c(g);
        }
    }, u.td = function(a) {
        try {
            var b = window.localStorage || l;
            b && (b.volume = a);
        } catch (c) {
            22 == c.code || 1014 == c.code ? u.log("LocalStorage Full (VideoJS)", c) : 18 == c.code ? u.log("LocalStorage not allowed (VideoJS)", c) : u.log("LocalStorage Error (VideoJS)", c);
        }
    }, u.mc = function(a) {
        return a.match(/^https?:\/\//) || (a = u.e("div", {
            innerHTML: '<a href="' + a + '">x</a>'
        }).firstChild.href), a;
    }, u.log = function() {
        u.log.history = u.log.history || [], u.log.history.push(arguments), window.console && window.console.log(Array.prototype.slice.call(arguments));
    }, u.ad = function(a) {
        var b, c;
        return a.getBoundingClientRect && a.parentNode && (b = a.getBoundingClientRect()), 
        b ? (a = document.documentElement, c = document.body, {
            left: b.left + (window.pageXOffset || c.scrollLeft) - (a.clientLeft || c.clientLeft || 0),
            top: b.top + (window.pageYOffset || c.scrollTop) - (a.clientTop || c.clientTop || 0)
        }) : {
            left: 0,
            top: 0
        };
    }, u.c = u.la.extend({
        i: function(a, b, c) {
            if (this.b = a, this.g = u.k.copy(this.g), b = this.options(b), this.Q = b.id || (b.el && b.el.id ? b.el.id : a.id() + "_component_" + u.t++), 
            this.gd = b.name || h, this.a = b.el || this.e(), this.G = [], this.qb = {}, this.V = {}, 
            (a = this.g) && a.children) {
                var d = this;
                u.k.ua(a.children, function(a, b) {
                    b !== l && !b.loadEvent && (d[a] = d.Z(a, b));
                });
            }
            this.L(c);
        }
    }), t = u.c.prototype, t.D = function() {
        if (this.j("dispose"), this.G) for (var a = this.G.length - 1; a >= 0; a--) this.G[a].D && this.G[a].D();
        this.V = this.qb = this.G = h, this.o(), this.a.parentNode && this.a.parentNode.removeChild(this.a), 
        u.vc(this.a), this.a = h;
    }, t.b = f, t.K = p("b"), t.options = function(a) {
        return a === b ? this.g : this.g = u.k.ic(this.g, a);
    }, t.e = function(a, b) {
        return u.e(a, b);
    }, t.w = p("a"), t.id = p("Q"), t.name = p("gd"), t.children = p("G"), t.Z = function(a, b) {
        var c, d;
        return "string" == typeof a ? (d = a, b = b || {}, c = b.componentClass || u.$(d), 
        b.name = d, c = new window.videojs[c](this.b || this, b)) : c = a, this.G.push(c), 
        "function" == typeof c.id && (this.qb[c.id()] = c), (d = d || c.name && c.name()) && (this.V[d] = c), 
        "function" == typeof c.el && c.el() && (this.sa || this.a).appendChild(c.el()), 
        c;
    }, t.removeChild = function(a) {
        if ("string" == typeof a && (a = this.V[a]), a && this.G) {
            for (var b = l, c = this.G.length - 1; c >= 0; c--) if (this.G[c] === a) {
                b = f, this.G.splice(c, 1);
                break;
            }
            b && (this.qb[a.id] = h, this.V[a.name] = h, (b = a.w()) && b.parentNode === (this.sa || this.a) && (this.sa || this.a).removeChild(a.w()));
        }
    }, t.T = s(""), t.d = function(a, b) {
        return u.d(this.a, a, u.bind(this, b)), this;
    }, t.o = function(a, b) {
        return u.o(this.a, a, b), this;
    }, t.U = function(a, b) {
        return u.U(this.a, a, u.bind(this, b)), this;
    }, t.j = function(a, b) {
        return u.j(this.a, a, b), this;
    }, t.L = function(a) {
        return a && (this.aa ? a.call(this) : (this.Sa === b && (this.Sa = []), this.Sa.push(a))), 
        this;
    }, t.Ua = function() {
        this.aa = f;
        var a = this.Sa;
        if (a && 0 < a.length) {
            for (var b = 0, c = a.length; c > b; b++) a[b].call(this);
            this.Sa = [], this.j("ready");
        }
    }, t.n = function(a) {
        return u.n(this.a, a), this;
    }, t.u = function(a) {
        return u.u(this.a, a), this;
    }, t.show = function() {
        return this.a.style.display = "block", this;
    }, t.C = function() {
        return this.a.style.display = "none", this;
    }, t.disable = function() {
        this.C(), this.show = m();
    }, t.width = function(a, b) {
        return E(this, "width", a, b);
    }, t.height = function(a, b) {
        return E(this, "height", a, b);
    }, t.Xc = function(a, b) {
        return this.width(a, f).height(b);
    }, u.q = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b);
            var c = l;
            this.d("touchstart", function(a) {
                a.preventDefault(), c = f;
            }), this.d("touchmove", function() {
                c = l;
            });
            var d = this;
            this.d("touchend", function(a) {
                c && d.p(a), a.preventDefault();
            }), this.d("click", this.p), this.d("focus", this.Oa), this.d("blur", this.Na);
        }
    }), t = u.q.prototype, t.e = function(a, b) {
        return b = u.k.B({
            className: this.T(),
            innerHTML: '<div class="vjs-control-content"><span class="vjs-control-text">' + (this.qa || "Need Text") + "</span></div>",
            qd: "button",
            "aria-live": "polite",
            tabIndex: 0
        }, b), u.c.prototype.e.call(this, a, b);
    }, t.T = function() {
        return "vjs-control " + u.c.prototype.T.call(this);
    }, t.p = m(), t.Oa = function() {
        u.d(document, "keyup", u.bind(this, this.ba));
    }, t.ba = function(a) {
        (32 == a.which || 13 == a.which) && (a.preventDefault(), this.p());
    }, t.Na = function() {
        u.o(document, "keyup", u.bind(this, this.ba));
    }, u.O = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), this.Sc = this.V[this.g.barName], this.handle = this.V[this.g.handleName], 
            a.d(this.tc, u.bind(this, this.update)), this.d("mousedown", this.Pa), this.d("touchstart", this.Pa), 
            this.d("focus", this.Oa), this.d("blur", this.Na), this.d("click", this.p), this.b.d("controlsvisible", u.bind(this, this.update)), 
            a.L(u.bind(this, this.update)), this.P = {};
        }
    }), t = u.O.prototype, t.e = function(a, b) {
        return b = b || {}, b.className += " vjs-slider", b = u.k.B({
            qd: "slider",
            "aria-valuenow": 0,
            "aria-valuemin": 0,
            "aria-valuemax": 100,
            tabIndex: 0
        }, b), u.c.prototype.e.call(this, a, b);
    }, t.Pa = function(a) {
        a.preventDefault(), u.Tc(), this.P.move = u.bind(this, this.Hb), this.P.end = u.bind(this, this.Ib), 
        u.d(document, "mousemove", this.P.move), u.d(document, "mouseup", this.P.end), u.d(document, "touchmove", this.P.move), 
        u.d(document, "touchend", this.P.end), this.Hb(a);
    }, t.Ib = function() {
        u.Bd(), u.o(document, "mousemove", this.P.move, l), u.o(document, "mouseup", this.P.end, l), 
        u.o(document, "touchmove", this.P.move, l), u.o(document, "touchend", this.P.end, l), 
        this.update();
    }, t.update = function() {
        if (this.a) {
            var a, b = this.yb(), c = this.handle, d = this.Sc;
            if (isNaN(b) && (b = 0), a = b, c) {
                a = this.a.offsetWidth;
                var e = c.w().offsetWidth;
                a = e ? e / a : 0, b *= 1 - a, a = b + a / 2, c.w().style.left = u.round(100 * b, 2) + "%";
            }
            d.w().style.width = u.round(100 * a, 2) + "%";
        }
    }, t.Oa = function() {
        u.d(document, "keyup", u.bind(this, this.ba));
    }, t.ba = function(a) {
        37 == a.which ? (a.preventDefault(), this.yc()) : 39 == a.which && (a.preventDefault(), 
        this.zc());
    }, t.Na = function() {
        u.o(document, "keyup", u.bind(this, this.ba));
    }, t.p = function(a) {
        a.stopImmediatePropagation(), a.preventDefault();
    }, u.ea = u.c.extend(), u.ea.prototype.defaultValue = 0, u.ea.prototype.e = function(a, b) {
        return b = b || {}, b.className += " vjs-slider-handle", b = u.k.B({
            innerHTML: '<span class="vjs-control-text">' + this.defaultValue + "</span>"
        }, b), u.c.prototype.e.call(this, "div", b);
    }, u.ma = u.c.extend(), u.ma.prototype.e = function() {
        var a = this.options().Vc || "ul";
        return this.sa = u.e(a, {
            className: "vjs-menu-content"
        }), a = u.c.prototype.e.call(this, "div", {
            append: this.sa,
            className: "vjs-menu"
        }), a.appendChild(this.sa), u.d(a, "click", function(a) {
            a.preventDefault(), a.stopImmediatePropagation();
        }), a;
    }, u.N = u.q.extend({
        i: function(a, b) {
            u.q.call(this, a, b), this.selected(b.selected);
        }
    }), u.N.prototype.e = function(a, b) {
        return u.q.prototype.e.call(this, "li", u.k.B({
            className: "vjs-menu-item",
            innerHTML: this.g.label
        }, b));
    }, u.N.prototype.p = function() {
        this.selected(f);
    }, u.N.prototype.selected = function(a) {
        a ? (this.n("vjs-selected"), this.a.setAttribute("aria-selected", f)) : (this.u("vjs-selected"), 
        this.a.setAttribute("aria-selected", l));
    }, u.R = u.q.extend({
        i: function(a, b) {
            u.q.call(this, a, b), this.wa = this.Ka(), this.Z(this.wa), this.I && 0 === this.I.length && this.C(), 
            this.d("keyup", this.ba), this.a.setAttribute("aria-haspopup", f), this.a.setAttribute("role", "button");
        }
    }), t = u.R.prototype, t.pa = l, t.Ka = function() {
        var a = new u.ma(this.b);
        if (this.options().title && a.w().appendChild(u.e("li", {
            className: "vjs-menu-title",
            innerHTML: u.$(this.A),
            zd: -1
        })), this.I = this.createItems()) for (var b = 0; b < this.I.length; b++) ca(a, this.I[b]);
        return a;
    }, t.ta = m(), t.T = function() {
        return this.className + " vjs-menu-button " + u.q.prototype.T.call(this);
    }, t.Oa = m(), t.Na = m(), t.p = function() {
        this.U("mouseout", u.bind(this, function() {
            D(this.wa), this.a.blur();
        })), this.pa ? G(this) : H(this);
    }, t.ba = function(a) {
        a.preventDefault(), 32 == a.which || 13 == a.which ? this.pa ? G(this) : H(this) : 27 == a.which && this.pa && G(this);
    }, u.s = u.c.extend({
        i: function(a, b, c) {
            this.M = a, b = u.k.B(da(a), b), this.v = {}, this.uc = b.poster, this.sb = b.controls, 
            a.controls = l, u.c.call(this, this, b, c), this.n(this.controls() ? "vjs-controls-enabled" : "vjs-controls-disabled"), 
            this.U("play", function(a) {
                u.j(this.a, {
                    type: "firstplay",
                    target: this.a
                }) || (a.preventDefault(), a.stopPropagation(), a.stopImmediatePropagation());
            }), this.d("ended", this.hd), this.d("play", this.Kb), this.d("firstplay", this.jd), 
            this.d("pause", this.Jb), this.d("progress", this.ld), this.d("durationchange", this.sc), 
            this.d("error", this.Gb), this.d("fullscreenchange", this.kd), u.xa[this.Q] = this, 
            b.plugins && u.k.ua(b.plugins, function(a, b) {
                this[a](b);
            }, this);
            var d, e, g, h;
            d = this.Mb, a = function() {
                d(), clearInterval(e), e = setInterval(u.bind(this, d), 250);
            }, b = function() {
                d(), clearInterval(e);
            }, this.d("mousedown", a), this.d("mousemove", d), this.d("mouseup", b), this.d("keydown", d), 
            this.d("keyup", d), this.d("touchstart", a), this.d("touchmove", d), this.d("touchend", b), 
            this.d("touchcancel", b), g = setInterval(u.bind(this, function() {
                this.ka && (this.ka = l, this.ja(f), clearTimeout(h), h = setTimeout(u.bind(this, function() {
                    this.ka || this.ja(l);
                }), 2e3));
            }), 250), this.d("dispose", function() {
                clearInterval(g), clearTimeout(h);
            });
        }
    }), t = u.s.prototype, t.g = u.options, t.D = function() {
        this.j("dispose"), this.o("dispose"), u.xa[this.Q] = h, this.M && this.M.player && (this.M.player = h), 
        this.a && this.a.player && (this.a.player = h), clearInterval(this.Ra), this.za(), 
        this.h && this.h.D(), u.c.prototype.D.call(this);
    }, t.e = function() {
        var a = this.a = u.c.prototype.e.call(this, "div"), b = this.M;
        if (b.removeAttribute("width"), b.removeAttribute("height"), b.hasChildNodes()) {
            var c, d, e, g, h;
            for (c = b.childNodes, d = c.length, h = []; d--; ) e = c[d], g = e.nodeName.toLowerCase(), 
            "track" === g && h.push(e);
            for (c = 0; c < h.length; c++) b.removeChild(h[c]);
        }
        return b.id = b.id || "vjs_video_" + u.t++, a.id = b.id, a.className = b.className, 
        b.id += "_html5_api", b.className = "vjs-tech", b.player = a.player = this, this.n("vjs-paused"), 
        this.width(this.g.width, f), this.height(this.g.height, f), b.parentNode && b.parentNode.insertBefore(a, b), 
        u.zb(b, a), a;
    }, t.Cc = function() {
        this.hc && this.za(), this.hc = setInterval(u.bind(this, function() {
            this.j("timeupdate");
        }), 250);
    }, t.za = function() {
        clearInterval(this.hc);
    }, t.Kb = function() {
        u.u(this.a, "vjs-paused"), u.n(this.a, "vjs-playing");
    }, t.jd = function() {
        this.g.starttime && this.currentTime(this.g.starttime), this.n("vjs-has-started");
    }, t.Jb = function() {
        u.u(this.a, "vjs-playing"), u.n(this.a, "vjs-paused");
    }, t.ld = function() {
        1 == this.Ja() && this.j("loadedalldata");
    }, t.hd = function() {
        this.g.loop && (this.currentTime(0), this.play());
    }, t.sc = function() {
        this.duration(K(this, "duration"));
    }, t.kd = function() {
        this.H ? this.n("vjs-fullscreen") : this.u("vjs-fullscreen");
    }, t.Gb = function(a) {
        u.log("Video Error", a);
    }, t.play = function() {
        return L(this, "play"), this;
    }, t.pause = function() {
        return L(this, "pause"), this;
    }, t.paused = function() {
        return K(this, "paused") === l ? l : f;
    }, t.currentTime = function(a) {
        return a !== b ? (this.v.rc = a, L(this, "setCurrentTime", a), this.Fb && this.j("timeupdate"), 
        this) : this.v.currentTime = K(this, "currentTime") || 0;
    }, t.duration = function(a) {
        return a !== b ? (this.v.duration = parseFloat(a), this) : (this.v.duration === b && this.sc(), 
        this.v.duration);
    }, t.buffered = function() {
        var a = K(this, "buffered"), b = a.length - 1, c = this.v.lb = this.v.lb || 0;
        return a && b >= 0 && a.end(b) !== c && (c = a.end(b), this.v.lb = c), u.tb(0, c);
    }, t.Ja = function() {
        return this.duration() ? this.buffered().end(0) / this.duration() : 0;
    }, t.volume = function(a) {
        return a !== b ? (a = Math.max(0, Math.min(1, parseFloat(a))), this.v.volume = a, 
        L(this, "setVolume", a), u.td(a), this) : (a = parseFloat(K(this, "volume")), isNaN(a) ? 1 : a);
    }, t.muted = function(a) {
        return a !== b ? (L(this, "setMuted", a), this) : K(this, "muted") || l;
    }, t.Ta = function() {
        return K(this, "supportsFullScreen") || l;
    }, t.ya = function() {
        var a = u.Pb.ya;
        return this.H = f, a ? (u.d(document, a.vb, u.bind(this, function() {
            this.H = document[a.H], this.H === l && u.o(document, a.vb, arguments.callee), this.j("fullscreenchange");
        })), this.a[a.wc]()) : this.h.Ta() ? L(this, "enterFullScreen") : (this.cd = f, 
        this.Yc = document.documentElement.style.overflow, u.d(document, "keydown", u.bind(this, this.lc)), 
        document.documentElement.style.overflow = "hidden", u.n(document.body, "vjs-full-window"), 
        this.j("enterFullWindow"), this.j("fullscreenchange")), this;
    }, t.ob = function() {
        var a = u.Pb.ya;
        return this.H = l, a ? document[a.nb]() : this.h.Ta() ? L(this, "exitFullScreen") : (M(this), 
        this.j("fullscreenchange")), this;
    }, t.lc = function(a) {
        27 === a.keyCode && (this.H === f ? this.ob() : M(this));
    }, t.src = function(a) {
        if (a instanceof Array) {
            var b;
            a: {
                b = a;
                for (var c = 0, d = this.g.techOrder; c < d.length; c++) {
                    var e = u.$(d[c]), f = window.videojs[e];
                    if (f.isSupported()) for (var g = 0, h = b; g < h.length; g++) {
                        var i = h[g];
                        if (f.canPlaySource(i)) {
                            b = {
                                source: i,
                                h: e
                            };
                            break a;
                        }
                    }
                }
                b = l;
            }
            b ? (a = b.source, b = b.h, b == this.ia ? this.src(a) : I(this, b, a)) : this.a.appendChild(u.e("p", {
                innerHTML: this.options().notSupportedMessage
            }));
        } else a instanceof Object ? this.src(window.videojs[this.ia].canPlaySource(a) ? a.src : [ a ]) : (this.v.src = a, 
        this.aa ? (L(this, "src", a), "auto" == this.g.preload && this.load(), this.g.autoplay && this.play()) : this.L(function() {
            this.src(a);
        }));
        return this;
    }, t.load = function() {
        return L(this, "load"), this;
    }, t.currentSrc = function() {
        return K(this, "currentSrc") || this.v.src || "";
    }, t.Qa = function(a) {
        return a !== b ? (L(this, "setPreload", a), this.g.preload = a, this) : K(this, "preload");
    }, t.autoplay = function(a) {
        return a !== b ? (L(this, "setAutoplay", a), this.g.autoplay = a, this) : K(this, "autoplay");
    }, t.loop = function(a) {
        return a !== b ? (L(this, "setLoop", a), this.g.loop = a, this) : K(this, "loop");
    }, t.poster = function(a) {
        return a !== b ? (this.uc = a, this) : this.uc;
    }, t.controls = function(a) {
        return a !== b ? (a = !!a, this.sb !== a && ((this.sb = a) ? (this.u("vjs-controls-disabled"), 
        this.n("vjs-controls-enabled"), this.j("controlsenabled")) : (this.u("vjs-controls-enabled"), 
        this.n("vjs-controls-disabled"), this.j("controlsdisabled"))), this) : this.sb;
    }, u.s.prototype.Sb, t = u.s.prototype, t.Rb = function(a) {
        return a !== b ? (a = !!a, this.Sb !== a && ((this.Sb = a) ? (this.n("vjs-using-native-controls"), 
        this.j("usingnativecontrols")) : (this.u("vjs-using-native-controls"), this.j("usingcustomcontrols"))), 
        this) : this.Sb;
    }, t.error = function() {
        return K(this, "error");
    }, t.seeking = function() {
        return K(this, "seeking");
    }, t.ka = f, t.Mb = function() {
        this.ka = f;
    }, t.Qb = f, t.ja = function(a) {
        return a !== b ? (a = !!a, a !== this.Qb && ((this.Qb = a) ? (this.ka = f, this.u("vjs-user-inactive"), 
        this.n("vjs-user-active"), this.j("useractive")) : (this.ka = l, this.h.U("mousemove", function(a) {
            a.stopPropagation(), a.preventDefault();
        }), this.u("vjs-user-active"), this.n("vjs-user-inactive"), this.j("userinactive"))), 
        this) : this.Qb;
    };
    var N, O, P;
    P = document.createElement("div"), O = {}, P.Hd !== b ? (O.wc = "requestFullscreen", 
    O.nb = "exitFullscreen", O.vb = "fullscreenchange", O.H = "fullScreen") : (document.mozCancelFullScreen ? (N = "moz", 
    O.H = N + "FullScreen") : (N = "webkit", O.H = N + "IsFullScreen"), P[N + "RequestFullScreen"] && (O.wc = N + "RequestFullScreen", 
    O.nb = N + "CancelFullScreen"), O.vb = N + "fullscreenchange"), document[O.nb] && (u.Pb.ya = O), 
    u.Fa = u.c.extend(), u.Fa.prototype.g = {
        Md: "play",
        children: {
            playToggle: {},
            currentTimeDisplay: {},
            timeDivider: {},
            durationDisplay: {},
            remainingTimeDisplay: {},
            progressControl: {},
            fullscreenToggle: {},
            volumeControl: {},
            muteToggle: {}
        }
    }, u.Fa.prototype.e = function() {
        return u.e("div", {
            className: "vjs-control-bar"
        });
    }, u.Yb = u.q.extend({
        i: function(a, b) {
            u.q.call(this, a, b), a.d("play", u.bind(this, this.Kb)), a.d("pause", u.bind(this, this.Jb));
        }
    }), t = u.Yb.prototype, t.qa = "Play", t.T = function() {
        return "vjs-play-control " + u.q.prototype.T.call(this);
    }, t.p = function() {
        this.b.paused() ? this.b.play() : this.b.pause();
    }, t.Kb = function() {
        u.u(this.a, "vjs-paused"), u.n(this.a, "vjs-playing"), this.a.children[0].children[0].innerHTML = "Pause";
    }, t.Jb = function() {
        u.u(this.a, "vjs-playing"), u.n(this.a, "vjs-paused"), this.a.children[0].children[0].innerHTML = "Play";
    }, u.Ya = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), a.d("timeupdate", u.bind(this, this.Ca));
        }
    }), u.Ya.prototype.e = function() {
        var a = u.c.prototype.e.call(this, "div", {
            className: "vjs-current-time vjs-time-controls vjs-control"
        });
        return this.content = u.e("div", {
            className: "vjs-current-time-display",
            innerHTML: '<span class="vjs-control-text">Current Time </span>0:00',
            "aria-live": "off"
        }), a.appendChild(u.e("div").appendChild(this.content)), a;
    }, u.Ya.prototype.Ca = function() {
        var a = this.b.Nb ? this.b.v.currentTime : this.b.currentTime();
        this.content.innerHTML = '<span class="vjs-control-text">Current Time </span>' + u.La(a, this.b.duration());
    }, u.Za = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), a.d("timeupdate", u.bind(this, this.Ca));
        }
    }), u.Za.prototype.e = function() {
        var a = u.c.prototype.e.call(this, "div", {
            className: "vjs-duration vjs-time-controls vjs-control"
        });
        return this.content = u.e("div", {
            className: "vjs-duration-display",
            innerHTML: '<span class="vjs-control-text">Duration Time </span>0:00',
            "aria-live": "off"
        }), a.appendChild(u.e("div").appendChild(this.content)), a;
    }, u.Za.prototype.Ca = function() {
        var a = this.b.duration();
        a && (this.content.innerHTML = '<span class="vjs-control-text">Duration Time </span>' + u.La(a));
    }, u.cc = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b);
        }
    }), u.cc.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-time-divider",
            innerHTML: "<div><span>/</span></div>"
        });
    }, u.fb = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), a.d("timeupdate", u.bind(this, this.Ca));
        }
    }), u.fb.prototype.e = function() {
        var a = u.c.prototype.e.call(this, "div", {
            className: "vjs-remaining-time vjs-time-controls vjs-control"
        });
        return this.content = u.e("div", {
            className: "vjs-remaining-time-display",
            innerHTML: '<span class="vjs-control-text">Remaining Time </span>-0:00',
            "aria-live": "off"
        }), a.appendChild(u.e("div").appendChild(this.content)), a;
    }, u.fb.prototype.Ca = function() {
        this.b.duration() && (this.content.innerHTML = '<span class="vjs-control-text">Remaining Time </span>-' + u.La(this.b.duration() - this.b.currentTime()));
    }, u.Ga = u.q.extend({
        i: function(a, b) {
            u.q.call(this, a, b);
        }
    }), u.Ga.prototype.qa = "Fullscreen", u.Ga.prototype.T = function() {
        return "vjs-fullscreen-control " + u.q.prototype.T.call(this);
    }, u.Ga.prototype.p = function() {
        this.b.H ? (this.b.ob(), this.a.children[0].children[0].innerHTML = "Fullscreen") : (this.b.ya(), 
        this.a.children[0].children[0].innerHTML = "Non-Fullscreen");
    }, u.eb = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b);
        }
    }), u.eb.prototype.g = {
        children: {
            seekBar: {}
        }
    }, u.eb.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-progress-control vjs-control"
        });
    }, u.Zb = u.O.extend({
        i: function(a, b) {
            u.O.call(this, a, b), a.d("timeupdate", u.bind(this, this.Ba)), a.L(u.bind(this, this.Ba));
        }
    }), t = u.Zb.prototype, t.g = {
        children: {
            loadProgressBar: {},
            playProgressBar: {},
            seekHandle: {}
        },
        barName: "playProgressBar",
        handleName: "seekHandle"
    }, t.tc = "timeupdate", t.e = function() {
        return u.O.prototype.e.call(this, "div", {
            className: "vjs-progress-holder",
            "aria-label": "video progress bar"
        });
    }, t.Ba = function() {
        var a = this.b.Nb ? this.b.v.currentTime : this.b.currentTime();
        this.a.setAttribute("aria-valuenow", u.round(100 * this.yb(), 2)), this.a.setAttribute("aria-valuetext", u.La(a, this.b.duration()));
    }, t.yb = function() {
        var a;
        return "Flash" === this.b.ia && this.b.seeking() ? (a = this.b.v, a = a.rc ? a.rc : this.b.currentTime()) : a = this.b.currentTime(), 
        a / this.b.duration();
    }, t.Pa = function(a) {
        u.O.prototype.Pa.call(this, a), this.b.Nb = f, this.Dd = !this.b.paused(), this.b.pause();
    }, t.Hb = function(a) {
        a = F(this, a) * this.b.duration(), a == this.b.duration() && (a -= .1), this.b.currentTime(a);
    }, t.Ib = function(a) {
        u.O.prototype.Ib.call(this, a), this.b.Nb = l, this.Dd && this.b.play();
    }, t.zc = function() {
        this.b.currentTime(this.b.currentTime() + 5);
    }, t.yc = function() {
        this.b.currentTime(this.b.currentTime() - 5);
    }, u.ab = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), a.d("progress", u.bind(this, this.update));
        }
    }), u.ab.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-load-progress",
            innerHTML: '<span class="vjs-control-text">Loaded: 0%</span>'
        });
    }, u.ab.prototype.update = function() {
        this.a.style && (this.a.style.width = u.round(100 * this.b.Ja(), 2) + "%");
    }, u.Xb = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b);
        }
    }), u.Xb.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-play-progress",
            innerHTML: '<span class="vjs-control-text">Progress: 0%</span>'
        });
    }, u.gb = u.ea.extend(), u.gb.prototype.defaultValue = "00:00", u.gb.prototype.e = function() {
        return u.ea.prototype.e.call(this, "div", {
            className: "vjs-seek-handle"
        });
    }, u.ib = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), a.h && a.h.m && a.h.m.volumeControl === l && this.n("vjs-hidden"), 
            a.d("loadstart", u.bind(this, function() {
                a.h.m && a.h.m.volumeControl === l ? this.n("vjs-hidden") : this.u("vjs-hidden");
            }));
        }
    }), u.ib.prototype.g = {
        children: {
            volumeBar: {}
        }
    }, u.ib.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-volume-control vjs-control"
        });
    }, u.hb = u.O.extend({
        i: function(a, b) {
            u.O.call(this, a, b), a.d("volumechange", u.bind(this, this.Ba)), a.L(u.bind(this, this.Ba)), 
            setTimeout(u.bind(this, this.update), 0);
        }
    }), t = u.hb.prototype, t.Ba = function() {
        this.a.setAttribute("aria-valuenow", u.round(100 * this.b.volume(), 2)), this.a.setAttribute("aria-valuetext", u.round(100 * this.b.volume(), 2) + "%");
    }, t.g = {
        children: {
            volumeLevel: {},
            volumeHandle: {}
        },
        barName: "volumeLevel",
        handleName: "volumeHandle"
    }, t.tc = "volumechange", t.e = function() {
        return u.O.prototype.e.call(this, "div", {
            className: "vjs-volume-bar",
            "aria-label": "volume level"
        });
    }, t.Hb = function(a) {
        this.b.muted() && this.b.muted(l), this.b.volume(F(this, a));
    }, t.yb = function() {
        return this.b.muted() ? 0 : this.b.volume();
    }, t.zc = function() {
        this.b.volume(this.b.volume() + .1);
    }, t.yc = function() {
        this.b.volume(this.b.volume() - .1);
    }, u.dc = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b);
        }
    }), u.dc.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-volume-level",
            innerHTML: '<span class="vjs-control-text"></span>'
        });
    }, u.jb = u.ea.extend(), u.jb.prototype.defaultValue = "00:00", u.jb.prototype.e = function() {
        return u.ea.prototype.e.call(this, "div", {
            className: "vjs-volume-handle"
        });
    }, u.da = u.q.extend({
        i: function(a, b) {
            u.q.call(this, a, b), a.d("volumechange", u.bind(this, this.update)), a.h && a.h.m && a.h.m.volumeControl === l && this.n("vjs-hidden"), 
            a.d("loadstart", u.bind(this, function() {
                a.h.m && a.h.m.volumeControl === l ? this.n("vjs-hidden") : this.u("vjs-hidden");
            }));
        }
    }), u.da.prototype.e = function() {
        return u.q.prototype.e.call(this, "div", {
            className: "vjs-mute-control vjs-control",
            innerHTML: '<div><span class="vjs-control-text">Mute</span></div>'
        });
    }, u.da.prototype.p = function() {
        this.b.muted(this.b.muted() ? l : f);
    }, u.da.prototype.update = function() {
        var a = this.b.volume(), b = 3;
        for (0 === a || this.b.muted() ? b = 0 : .33 > a ? b = 1 : .67 > a && (b = 2), this.b.muted() ? "Unmute" != this.a.children[0].children[0].innerHTML && (this.a.children[0].children[0].innerHTML = "Unmute") : "Mute" != this.a.children[0].children[0].innerHTML && (this.a.children[0].children[0].innerHTML = "Mute"), 
        a = 0; 4 > a; a++) u.u(this.a, "vjs-vol-" + a);
        u.n(this.a, "vjs-vol-" + b);
    }, u.oa = u.R.extend({
        i: function(a, b) {
            u.R.call(this, a, b), a.d("volumechange", u.bind(this, this.update)), a.h && a.h.m && a.h.m.Dc === l && this.n("vjs-hidden"), 
            a.d("loadstart", u.bind(this, function() {
                a.h.m && a.h.m.Dc === l ? this.n("vjs-hidden") : this.u("vjs-hidden");
            })), this.n("vjs-menu-button");
        }
    }), u.oa.prototype.Ka = function() {
        var a = new u.ma(this.b, {
            Vc: "div"
        }), b = new u.hb(this.b, u.k.B({
            Cd: f
        }, this.g.Vd));
        return a.Z(b), a;
    }, u.oa.prototype.p = function() {
        u.da.prototype.p.call(this), u.R.prototype.p.call(this);
    }, u.oa.prototype.e = function() {
        return u.q.prototype.e.call(this, "div", {
            className: "vjs-volume-menu-button vjs-menu-button vjs-control",
            innerHTML: '<div><span class="vjs-control-text">Mute</span></div>'
        });
    }, u.oa.prototype.update = u.da.prototype.update, u.cb = u.q.extend({
        i: function(a, b) {
            u.q.call(this, a, b), (!a.poster() || !a.controls()) && this.C(), a.d("play", u.bind(this, this.C));
        }
    }), u.cb.prototype.e = function() {
        var a = u.e("div", {
            className: "vjs-poster",
            tabIndex: -1
        }), b = this.b.poster();
        return b && ("backgroundSize" in a.style ? a.style.backgroundImage = 'url("' + b + '")' : a.appendChild(u.e("img", {
            src: b
        }))), a;
    }, u.cb.prototype.p = function() {
        this.K().controls() && this.b.play();
    }, u.Wb = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), a.d("canplay", u.bind(this, this.C)), a.d("canplaythrough", u.bind(this, this.C)), 
            a.d("playing", u.bind(this, this.C)), a.d("seeked", u.bind(this, this.C)), a.d("seeking", u.bind(this, this.show)), 
            a.d("seeked", u.bind(this, this.C)), a.d("error", u.bind(this, this.show)), a.d("waiting", u.bind(this, this.show));
        }
    }), u.Wb.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-loading-spinner"
        });
    }, u.Wa = u.q.extend(), u.Wa.prototype.e = function() {
        return u.q.prototype.e.call(this, "div", {
            className: "vjs-big-play-button",
            innerHTML: '<span aria-hidden="true"></span>',
            "aria-label": "play video"
        });
    }, u.Wa.prototype.p = function() {
        this.b.play();
    }, u.r = u.c.extend({
        i: function(a, b, c) {
            u.c.call(this, a, b, c);
            var d, e;
            e = this, d = this.K(), a = function() {
                if (d.controls() && !d.Rb()) {
                    var a, b;
                    e.d("mousedown", e.p), e.d("touchstart", function(a) {
                        a.preventDefault(), a.stopPropagation(), b = this.b.ja();
                    }), a = function(a) {
                        a.stopPropagation(), b && this.b.Mb();
                    }, e.d("touchmove", a), e.d("touchleave", a), e.d("touchcancel", a), e.d("touchend", a);
                    var c, g, h;
                    c = 0, e.d("touchstart", function() {
                        c = new Date().getTime(), h = f;
                    }), a = function() {
                        h = l;
                    }, e.d("touchmove", a), e.d("touchleave", a), e.d("touchcancel", a), e.d("touchend", function() {
                        h === f && (g = new Date().getTime() - c, 250 > g && this.j("tap"));
                    }), e.d("tap", e.md);
                }
            }, b = u.bind(e, e.pd), this.L(a), d.d("controlsenabled", a), d.d("controlsdisabled", b);
        }
    }), u.r.prototype.pd = function() {
        this.o("tap"), this.o("touchstart"), this.o("touchmove"), this.o("touchleave"), 
        this.o("touchcancel"), this.o("touchend"), this.o("click"), this.o("mousedown");
    }, u.r.prototype.p = function(a) {
        0 === a.button && this.K().controls() && (this.K().paused() ? this.K().play() : this.K().pause());
    }, u.r.prototype.md = function() {
        this.K().ja(!this.K().ja());
    }, u.r.prototype.m = {
        volumeControl: f,
        fullscreenResize: l,
        progressEvents: l,
        timeupdateEvents: l
    }, u.media = {}, u.media.Va = "play pause paused currentTime setCurrentTime duration buffered volume setVolume muted setMuted width height supportsFullScreen enterFullScreen src load currentSrc preload setPreload autoplay setAutoplay loop setLoop error networkState readyState seeking initialTime startOffsetTime played seekable ended videoTracks audioTracks videoWidth videoHeight textTracks defaultPlaybackRate playbackRate mediaGroup controller controls defaultMuted".split(" ");
    for (var i = u.media.Va.length - 1; i >= 0; i--) u.r.prototype[u.media.Va[i]] = ea();
    u.l = u.r.extend({
        i: function(a, b, c) {
            if (this.m.volumeControl = u.l.Uc(), this.m.movingMediaElementInDOM = !u.Kc, this.m.fullscreenResize = f, 
            u.r.call(this, a, b, c), (b = b.source) && this.a.currentSrc === b.src && 0 < this.a.networkState ? a.j("loadstart") : b && (this.a.src = b.src), 
            u.ac && a.options().nativeControlsForTouch !== l) {
                var d, e, g, h;
                d = this, e = this.K(), b = e.controls(), d.a.controls = !!b, g = function() {
                    d.a.controls = f;
                }, h = function() {
                    d.a.controls = l;
                }, e.d("controlsenabled", g), e.d("controlsdisabled", h), b = function() {
                    e.o("controlsenabled", g), e.o("controlsdisabled", h);
                }, d.d("dispose", b), e.d("usingcustomcontrols", b), e.Rb(f);
            }
            for (a.L(function() {
                this.M && this.g.autoplay && this.paused() && (delete this.M.poster, this.play());
            }), a = u.l.$a.length - 1; a >= 0; a--) u.d(this.a, u.l.$a[a], u.bind(this.b, this.$c));
            this.Ua();
        }
    }), t = u.l.prototype, t.D = function() {
        u.r.prototype.D.call(this);
    }, t.e = function() {
        var a, b = this.b, c = b.M;
        c && this.m.movingMediaElementInDOM !== l || (c ? (a = c.cloneNode(l), u.l.jc(c), 
        c = a, b.M = h) : c = u.e("video", {
            id: b.id() + "_html5_api",
            className: "vjs-tech"
        }), c.player = b, u.zb(c, b.w())), a = [ "autoplay", "preload", "loop", "muted" ];
        for (var d = a.length - 1; d >= 0; d--) {
            var e = a[d];
            b.g[e] !== h && (c[e] = b.g[e]);
        }
        return c;
    }, t.$c = function(a) {
        this.j(a), a.stopPropagation();
    }, t.play = function() {
        this.a.play();
    }, t.pause = function() {
        this.a.pause();
    }, t.paused = function() {
        return this.a.paused;
    }, t.currentTime = function() {
        return this.a.currentTime;
    }, t.sd = function(a) {
        try {
            this.a.currentTime = a;
        } catch (b) {
            u.log(b, "Video is not ready. (Video.js)");
        }
    }, t.duration = function() {
        return this.a.duration || 0;
    }, t.buffered = function() {
        return this.a.buffered;
    }, t.volume = function() {
        return this.a.volume;
    }, t.xd = function(a) {
        this.a.volume = a;
    }, t.muted = function() {
        return this.a.muted;
    }, t.vd = function(a) {
        this.a.muted = a;
    }, t.width = function() {
        return this.a.offsetWidth;
    }, t.height = function() {
        return this.a.offsetHeight;
    }, t.Ta = function() {
        return "function" != typeof this.a.webkitEnterFullScreen || !/Android/.test(u.F) && /Chrome|Mac OS X 10.5/.test(u.F) ? l : f;
    }, t.src = function(a) {
        this.a.src = a;
    }, t.load = function() {
        this.a.load();
    }, t.currentSrc = function() {
        return this.a.currentSrc;
    }, t.Qa = function() {
        return this.a.Qa;
    }, t.wd = function(a) {
        this.a.Qa = a;
    }, t.autoplay = function() {
        return this.a.autoplay;
    }, t.rd = function(a) {
        this.a.autoplay = a;
    }, t.controls = function() {
        return this.a.controls;
    }, t.loop = function() {
        return this.a.loop;
    }, t.ud = function(a) {
        this.a.loop = a;
    }, t.error = function() {
        return this.a.error;
    }, t.seeking = function() {
        return this.a.seeking;
    }, u.l.isSupported = function() {
        return !!u.na.canPlayType;
    }, u.l.mb = function(a) {
        try {
            return !!u.na.canPlayType(a.type);
        } catch (b) {
            return "";
        }
    }, u.l.Uc = function() {
        var a = u.na.volume;
        return u.na.volume = a / 2 + .1, a !== u.na.volume;
    }, u.l.$a = "loadstart suspend abort error emptied stalled loadedmetadata loadeddata canplay canplaythrough playing waiting seeking seeked ended durationchange timeupdate progress play pause ratechange volumechange".split(" "), 
    u.l.jc = function(a) {
        if (a) {
            for (a.player = h, a.parentNode && a.parentNode.removeChild(a); a.hasChildNodes(); ) a.removeChild(a.firstChild);
            a.removeAttribute("src"), "function" == typeof a.load && a.load();
        }
    }, u.Oc && (document.createElement("video").constructor.prototype.canPlayType = function(a) {
        return a && -1 != a.toLowerCase().indexOf("video/mp4") ? "maybe" : "";
    }), u.f = u.r.extend({
        i: function(a, b, c) {
            u.r.call(this, a, b, c);
            var d = b.source;
            c = b.parentEl;
            var e = this.a = u.e("div", {
                id: a.id() + "_temp_flash"
            }), g = a.id() + "_flash_api";
            a = a.g;
            var h = u.k.B({
                readyFunction: "videojs.Flash.onReady",
                eventProxyFunction: "videojs.Flash.onEvent",
                errorEventProxyFunction: "videojs.Flash.onError",
                autoplay: a.autoplay,
                preload: a.Qa,
                loop: a.loop,
                muted: a.muted
            }, b.flashVars), i = u.k.B({
                wmode: "opaque",
                bgcolor: "#000000"
            }, b.params), j = u.k.B({
                id: g,
                name: g,
                "class": "vjs-tech"
            }, b.attributes);
            if (d && (d.type && u.f.ed(d.type) ? (a = u.f.Ac(d.src), h.rtmpConnection = encodeURIComponent(a.rb), 
            h.rtmpStream = encodeURIComponent(a.Ob)) : h.src = encodeURIComponent(u.mc(d.src))), 
            u.zb(e, c), b.startTime && this.L(function() {
                this.load(), this.play(), this.currentTime(b.startTime);
            }), b.iFrameMode !== f || u.Jc) u.f.Zc(b.swf, e, h, i, j); else {
                var k = u.e("iframe", {
                    id: g + "_iframe",
                    name: g + "_iframe",
                    className: "vjs-tech",
                    scrolling: "no",
                    marginWidth: 0,
                    marginHeight: 0,
                    frameBorder: 0
                });
                h.readyFunction = "ready", h.eventProxyFunction = "events", h.errorEventProxyFunction = "errors", 
                u.d(k, "load", u.bind(this, function() {
                    var a, c = k.contentWindow;
                    a = k.contentDocument ? k.contentDocument : k.contentWindow.document, a.write(u.f.nc(b.swf, h, i, j)), 
                    c.player = this.b, c.ready = u.bind(this.b, function(b) {
                        var c = this.h;
                        c.a = a.getElementById(b), u.f.pb(c);
                    }), c.events = u.bind(this.b, function(a, b) {
                        this && "flash" === this.ia && this.j(b);
                    }), c.errors = u.bind(this.b, function(a, b) {
                        u.log("Flash Error", b);
                    });
                })), e.parentNode.replaceChild(k, e);
            }
        }
    }), t = u.f.prototype, t.D = function() {
        u.r.prototype.D.call(this);
    }, t.play = function() {
        this.a.vjs_play();
    }, t.pause = function() {
        this.a.vjs_pause();
    }, t.src = function(a) {
        if (u.f.dd(a) ? (a = u.f.Ac(a), this.Qd(a.rb), this.Rd(a.Ob)) : (a = u.mc(a), this.a.vjs_src(a)), 
        this.b.autoplay()) {
            var b = this;
            setTimeout(function() {
                b.play();
            }, 0);
        }
    }, t.currentSrc = function() {
        var a = this.a.vjs_getProperty("currentSrc");
        if (a == h) {
            var b = this.Od(), c = this.Pd();
            b && c && (a = u.f.yd(b, c));
        }
        return a;
    }, t.load = function() {
        this.a.vjs_load();
    }, t.poster = function() {
        this.a.vjs_getProperty("poster");
    }, t.buffered = function() {
        return u.tb(0, this.a.vjs_getProperty("buffered"));
    }, t.Ta = s(l);
    var Q = u.f.prototype, R = "rtmpConnection rtmpStream preload currentTime defaultPlaybackRate playbackRate autoplay loop mediaGroup controller controls volume muted defaultMuted".split(" "), S = "error currentSrc networkState readyState seeking initialTime duration startOffsetTime paused played seekable ended videoTracks audioTracks videoWidth videoHeight textTracks".split(" "), T;
    for (T = 0; T < R.length; T++) U(R[T]), fa();
    for (T = 0; T < S.length; T++) U(S[T]);
    if (u.f.isSupported = function() {
        return 10 <= u.f.version()[0];
    }, u.f.mb = function(a) {
        return a.type ? (a = a.type.replace(/;.*/, "").toLowerCase(), a in u.f.bd || a in u.f.Bc ? "maybe" : void 0) : "";
    }, u.f.bd = {
        "video/flv": "FLV",
        "video/x-flv": "FLV",
        "video/mp4": "MP4",
        "video/m4v": "MP4"
    }, u.f.Bc = {
        "rtmp/mp4": "MP4",
        "rtmp/flv": "FLV"
    }, u.f.onReady = function(a) {
        a = u.w(a);
        var b = a.player || a.parentNode.player, c = b.h;
        a.player = b, c.a = a, u.f.pb(c);
    }, u.f.pb = function(a) {
        a.w().vjs_getProperty ? a.Ua() : setTimeout(function() {
            u.f.pb(a);
        }, 50);
    }, u.f.onEvent = function(a, b) {
        u.w(a).player.j(b);
    }, u.f.onError = function(a, b) {
        u.w(a).player.j("error"), u.log("Flash Error", b, a);
    }, u.f.version = function() {
        var a = "0,0,0";
        try {
            a = new window.ActiveXObject("ShockwaveFlash.ShockwaveFlash").GetVariable("$version").replace(/\D+/g, ",").match(/^,?(.+),?$/)[1];
        } catch (b) {
            try {
                navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin && (a = (navigator.plugins["Shockwave Flash 2.0"] || navigator.plugins["Shockwave Flash"]).description.replace(/\D+/g, ",").match(/^,?(.+),?$/)[1]);
            } catch (c) {}
        }
        return a.split(",");
    }, u.f.Zc = function(a, b, c, d, e) {
        a = u.f.nc(a, c, d, e), a = u.e("div", {
            innerHTML: a
        }).childNodes[0], c = b.parentNode, b.parentNode.replaceChild(a, b);
        var f = c.childNodes[0];
        setTimeout(function() {
            f.style.display = "block";
        }, 1e3);
    }, u.f.nc = function(a, b, c, d) {
        var e = "", f = "", g = "";
        return b && u.k.ua(b, function(a, b) {
            e += a + "=" + b + "&amp;";
        }), c = u.k.B({
            movie: a,
            flashvars: e,
            allowScriptAccess: "always",
            allowNetworking: "all"
        }, c), u.k.ua(c, function(a, b) {
            f += '<param name="' + a + '" value="' + b + '" />';
        }), d = u.k.B({
            data: a,
            width: "100%",
            height: "100%"
        }, d), u.k.ua(d, function(a, b) {
            g += a + '="' + b + '" ';
        }), '<object type="application/x-shockwave-flash"' + g + ">" + f + "</object>";
    }, u.f.yd = function(a, b) {
        return a + "&" + b;
    }, u.f.Ac = function(a) {
        var b = {
            rb: "",
            Ob: ""
        };
        if (!a) return b;
        var c, d = a.indexOf("&");
        return -1 !== d ? c = d + 1 : (d = c = a.lastIndexOf("/") + 1, 0 === d && (d = c = a.length)), 
        b.rb = a.substring(0, d), b.Ob = a.substring(c, a.length), b;
    }, u.f.ed = function(a) {
        return a in u.f.Bc;
    }, u.f.Qc = /^rtmp[set]?:\/\//i, u.f.dd = function(a) {
        return u.f.Qc.test(a);
    }, u.Pc = u.c.extend({
        i: function(a, b, c) {
            if (u.c.call(this, a, b, c), a.g.sources && 0 !== a.g.sources.length) a.src(a.g.sources); else for (b = 0, 
            c = a.g.techOrder; b < c.length; b++) {
                var d = u.$(c[b]), e = window.videojs[d];
                if (e && e.isSupported()) {
                    I(a, d);
                    break;
                }
            }
        }
    }), u.X = u.c.extend({
        i: function(a, b) {
            u.c.call(this, a, b), this.Q = b.id || "vjs_" + b.kind + "_" + b.language + "_" + u.t++, 
            this.xc = b.src, this.Wc = b["default"] || b.dflt, this.Ad = b.title, this.Ld = b.srclang, 
            this.fd = b.label, this.fa = [], this.ec = [], this.ga = this.ha = 0, this.b.d("fullscreenchange", u.bind(this, this.Rc));
        }
    }), t = u.X.prototype, t.J = p("A"), t.src = p("xc"), t.ub = p("Wc"), t.title = p("Ad"), 
    t.label = p("fd"), t.readyState = p("ha"), t.mode = p("ga"), t.Rc = function() {
        this.a.style.fontSize = this.b.H ? 140 * (screen.width / this.b.width()) + "%" : "";
    }, t.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-" + this.A + " vjs-text-track"
        });
    }, t.show = function() {
        X(this), this.ga = 2, u.c.prototype.show.call(this);
    }, t.C = function() {
        X(this), this.ga = 1, u.c.prototype.C.call(this);
    }, t.disable = function() {
        2 == this.ga && this.C(), this.b.o("timeupdate", u.bind(this, this.update, this.Q)), 
        this.b.o("ended", u.bind(this, this.reset, this.Q)), this.reset(), this.b.V.textTrackDisplay.removeChild(this), 
        this.ga = 0;
    }, t.load = function() {
        0 === this.ha && (this.ha = 1, u.get(this.xc, u.bind(this, this.nd), u.bind(this, this.Gb)));
    }, t.Gb = function(a) {
        this.error = a, this.ha = 3, this.j("error");
    }, t.nd = function(a) {
        var b, c;
        a = a.split("\n");
        for (var d = "", e = 1, f = a.length; f > e; e++) if (d = u.trim(a[e])) {
            for (-1 == d.indexOf("-->") ? (b = d, d = u.trim(a[++e])) : b = this.fa.length, 
            b = {
                id: b,
                index: this.fa.length
            }, c = d.split(" --> "), b.startTime = Y(c[0]), b.va = Y(c[1]), c = []; a[++e] && (d = u.trim(a[e])); ) c.push(d);
            b.text = c.join("<br/>"), this.fa.push(b);
        }
        this.ha = 2, this.j("loaded");
    }, t.update = function() {
        if (0 < this.fa.length) {
            var a = this.b.currentTime();
            if (this.Lb === b || a < this.Lb || this.Ma <= a) {
                var c, d, e, g, h = this.fa, i = this.b.duration(), j = 0, k = l, m = [];
                for (a >= this.Ma || this.Ma === b ? g = this.wb !== b ? this.wb : 0 : (k = f, g = this.Db !== b ? this.Db : h.length - 1); ;) {
                    if (e = h[g], e.va <= a) j = Math.max(j, e.va), e.Ia && (e.Ia = l); else if (a < e.startTime) {
                        if (i = Math.min(i, e.startTime), e.Ia && (e.Ia = l), !k) break;
                    } else k ? (m.splice(0, 0, e), d === b && (d = g), c = g) : (m.push(e), c === b && (c = g), 
                    d = g), i = Math.min(i, e.va), j = Math.max(j, e.startTime), e.Ia = f;
                    if (k) {
                        if (0 === g) break;
                        g--;
                    } else {
                        if (g === h.length - 1) break;
                        g++;
                    }
                }
                for (this.ec = m, this.Ma = i, this.Lb = j, this.wb = c, this.Db = d, a = this.ec, 
                h = "", i = 0, j = a.length; j > i; i++) h += '<span class="vjs-tt-cue">' + a[i].text + "</span>";
                this.a.innerHTML = h, this.j("cuechange");
            }
        }
    }, t.reset = function() {
        this.Ma = 0, this.Lb = this.b.duration(), this.Db = this.wb = 0;
    }, u.Ub = u.X.extend(), u.Ub.prototype.A = "captions", u.$b = u.X.extend(), u.$b.prototype.A = "subtitles", 
    u.Vb = u.X.extend(), u.Vb.prototype.A = "chapters", u.bc = u.c.extend({
        i: function(a, b, c) {
            if (u.c.call(this, a, b, c), a.g.tracks && 0 < a.g.tracks.length) {
                b = this.b, a = a.g.tracks;
                var d;
                for (c = 0; c < a.length; c++) {
                    d = a[c];
                    var e = b, f = d.kind, g = d.label, h = d.language, i = d;
                    d = e.Aa = e.Aa || [], i = i || {}, i.kind = f, i.label = g, i.language = h, f = u.$(f || "subtitles"), 
                    e = new window.videojs[f + "Track"](e, i), d.push(e);
                }
            }
        }
    }), u.bc.prototype.e = function() {
        return u.c.prototype.e.call(this, "div", {
            className: "vjs-text-track-display"
        });
    }, u.Y = u.N.extend({
        i: function(a, b) {
            var c = this.ca = b.track;
            b.label = c.label(), b.selected = c.ub(), u.N.call(this, a, b), this.b.d(c.J() + "trackchange", u.bind(this, this.update));
        }
    }), u.Y.prototype.p = function() {
        u.N.prototype.p.call(this), W(this.b, this.ca.Q, this.ca.J());
    }, u.Y.prototype.update = function() {
        this.selected(2 == this.ca.mode());
    }, u.bb = u.Y.extend({
        i: function(a, b) {
            b.track = {
                J: function() {
                    return b.kind;
                },
                K: a,
                label: function() {
                    return b.kind + " off";
                },
                ub: s(l),
                mode: s(l)
            }, u.Y.call(this, a, b), this.selected(f);
        }
    }), u.bb.prototype.p = function() {
        u.Y.prototype.p.call(this), W(this.b, this.ca.Q, this.ca.J());
    }, u.bb.prototype.update = function() {
        for (var a, b = V(this.b), c = 0, d = b.length, e = f; d > c; c++) a = b[c], a.J() == this.ca.J() && 2 == a.mode() && (e = l);
        this.selected(e);
    }, u.S = u.R.extend({
        i: function(a, b) {
            u.R.call(this, a, b), 1 >= this.I.length && this.C();
        }
    }), u.S.prototype.ta = function() {
        var a, b = [];
        b.push(new u.bb(this.b, {
            kind: this.A
        }));
        for (var c = 0; c < V(this.b).length; c++) a = V(this.b)[c], a.J() === this.A && b.push(new u.Y(this.b, {
            track: a
        }));
        return b;
    }, u.Da = u.S.extend({
        i: function(a, b, c) {
            u.S.call(this, a, b, c), this.a.setAttribute("aria-label", "Captions Menu");
        }
    }), u.Da.prototype.A = "captions", u.Da.prototype.qa = "Captions", u.Da.prototype.className = "vjs-captions-button", 
    u.Ha = u.S.extend({
        i: function(a, b, c) {
            u.S.call(this, a, b, c), this.a.setAttribute("aria-label", "Subtitles Menu");
        }
    }), u.Ha.prototype.A = "subtitles", u.Ha.prototype.qa = "Subtitles", u.Ha.prototype.className = "vjs-subtitles-button", 
    u.Ea = u.S.extend({
        i: function(a, b, c) {
            u.S.call(this, a, b, c), this.a.setAttribute("aria-label", "Chapters Menu");
        }
    }), t = u.Ea.prototype, t.A = "chapters", t.qa = "Chapters", t.className = "vjs-chapters-button", 
    t.ta = function() {
        for (var a, b = [], c = 0; c < V(this.b).length; c++) a = V(this.b)[c], a.J() === this.A && b.push(new u.Y(this.b, {
            track: a
        }));
        return b;
    }, t.Ka = function() {
        for (var a, b, c = V(this.b), d = 0, e = c.length, f = this.I = []; e > d; d++) if (a = c[d], 
        a.J() == this.A && a.ub()) {
            if (2 > a.readyState()) return this.Id = a, void a.d("loaded", u.bind(this, this.Ka));
            b = a;
            break;
        }
        if (c = this.wa = new u.ma(this.b), c.a.appendChild(u.e("li", {
            className: "vjs-menu-title",
            innerHTML: u.$(this.A),
            zd: -1
        })), b) {
            a = b.fa;
            for (var g, d = 0, e = a.length; e > d; d++) g = a[d], g = new u.Xa(this.b, {
                track: b,
                cue: g
            }), f.push(g), c.Z(g);
        }
        return 0 < this.I.length && this.show(), c;
    }, u.Xa = u.N.extend({
        i: function(a, b) {
            var c = this.ca = b.track, d = this.cue = b.cue, e = a.currentTime();
            b.label = d.text, b.selected = d.startTime <= e && e < d.va, u.N.call(this, a, b), 
            c.d("cuechange", u.bind(this, this.update));
        }
    }), u.Xa.prototype.p = function() {
        u.N.prototype.p.call(this), this.b.currentTime(this.cue.startTime), this.update(this.cue.startTime);
    }, u.Xa.prototype.update = function() {
        var a = this.cue, b = this.b.currentTime();
        this.selected(a.startTime <= b && b < a.va);
    }, u.k.B(u.Fa.prototype.g.children, {
        subtitlesButton: {},
        captionsButton: {},
        chaptersButton: {}
    }), "undefined" != typeof window.JSON && "function" === window.JSON.parse) u.JSON = window.JSON; else {
        u.JSON = {};
        var Z = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
        u.JSON.parse = function(a, c) {
            function d(a, e) {
                var f, g, h = a[e];
                if (h && "object" == typeof h) for (f in h) Object.prototype.hasOwnProperty.call(h, f) && (g = d(h, f), 
                g !== b ? h[f] = g : delete h[f]);
                return c.call(a, e, h);
            }
            var e;
            if (a = String(a), Z.lastIndex = 0, Z.test(a) && (a = a.replace(Z, function(a) {
                return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
            })), /^[\],:{}\s]*$/.test(a.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) return e = eval("(" + a + ")"), 
            "function" == typeof c ? d({
                "": e
            }, "") : e;
            throw new SyntaxError("JSON.parse(): invalid or malformed JSON data");
        };
    }
    u.fc = function() {
        var a, c, d = document.getElementsByTagName("video");
        if (d && 0 < d.length) for (var e = 0, f = d.length; f > e; e++) {
            if (!(c = d[e]) || !c.getAttribute) {
                u.kb();
                break;
            }
            c.player === b && (a = c.getAttribute("data-setup"), a !== h && (a = u.JSON.parse(a || "{}"), 
            v(c, a)));
        } else u.Ec || u.kb();
    }, u.kb = function() {
        setTimeout(u.fc, 1);
    }, "complete" === document.readyState ? u.Ec = f : u.U(window, "load", function() {
        u.Ec = f;
    }), u.kb(), u.od = function(a, b) {
        u.s.prototype[a] = b;
    };
    var ga = this;
    ga.Ed = f, $("videojs", u), $("_V_", u), $("videojs.options", u.options), $("videojs.players", u.xa), 
    $("videojs.TOUCH_ENABLED", u.ac), $("videojs.cache", u.ra), $("videojs.Component", u.c), 
    u.c.prototype.player = u.c.prototype.K, u.c.prototype.dispose = u.c.prototype.D, 
    u.c.prototype.createEl = u.c.prototype.e, u.c.prototype.el = u.c.prototype.w, u.c.prototype.addChild = u.c.prototype.Z, 
    u.c.prototype.children = u.c.prototype.children, u.c.prototype.on = u.c.prototype.d, 
    u.c.prototype.off = u.c.prototype.o, u.c.prototype.one = u.c.prototype.U, u.c.prototype.trigger = u.c.prototype.j, 
    u.c.prototype.triggerReady = u.c.prototype.Ua, u.c.prototype.show = u.c.prototype.show, 
    u.c.prototype.hide = u.c.prototype.C, u.c.prototype.width = u.c.prototype.width, 
    u.c.prototype.height = u.c.prototype.height, u.c.prototype.dimensions = u.c.prototype.Xc, 
    u.c.prototype.ready = u.c.prototype.L, u.c.prototype.addClass = u.c.prototype.n, 
    u.c.prototype.removeClass = u.c.prototype.u, $("videojs.Player", u.s), u.s.prototype.dispose = u.s.prototype.D, 
    u.s.prototype.requestFullScreen = u.s.prototype.ya, u.s.prototype.cancelFullScreen = u.s.prototype.ob, 
    u.s.prototype.bufferedPercent = u.s.prototype.Ja, u.s.prototype.usingNativeControls = u.s.prototype.Rb, 
    u.s.prototype.reportUserActivity = u.s.prototype.Mb, u.s.prototype.userActive = u.s.prototype.ja, 
    $("videojs.MediaLoader", u.Pc), $("videojs.TextTrackDisplay", u.bc), $("videojs.ControlBar", u.Fa), 
    $("videojs.Button", u.q), $("videojs.PlayToggle", u.Yb), $("videojs.FullscreenToggle", u.Ga), 
    $("videojs.BigPlayButton", u.Wa), $("videojs.LoadingSpinner", u.Wb), $("videojs.CurrentTimeDisplay", u.Ya), 
    $("videojs.DurationDisplay", u.Za), $("videojs.TimeDivider", u.cc), $("videojs.RemainingTimeDisplay", u.fb), 
    $("videojs.Slider", u.O), $("videojs.ProgressControl", u.eb), $("videojs.SeekBar", u.Zb), 
    $("videojs.LoadProgressBar", u.ab), $("videojs.PlayProgressBar", u.Xb), $("videojs.SeekHandle", u.gb), 
    $("videojs.VolumeControl", u.ib), $("videojs.VolumeBar", u.hb), $("videojs.VolumeLevel", u.dc), 
    $("videojs.VolumeMenuButton", u.oa), $("videojs.VolumeHandle", u.jb), $("videojs.MuteToggle", u.da), 
    $("videojs.PosterImage", u.cb), $("videojs.Menu", u.ma), $("videojs.MenuItem", u.N), 
    $("videojs.MenuButton", u.R), u.R.prototype.createItems = u.R.prototype.ta, u.S.prototype.createItems = u.S.prototype.ta, 
    u.Ea.prototype.createItems = u.Ea.prototype.ta, $("videojs.SubtitlesButton", u.Ha), 
    $("videojs.CaptionsButton", u.Da), $("videojs.ChaptersButton", u.Ea), $("videojs.MediaTechController", u.r), 
    u.r.prototype.features = u.r.prototype.m, u.r.prototype.m.volumeControl = u.r.prototype.m.Dc, 
    u.r.prototype.m.fullscreenResize = u.r.prototype.m.Jd, u.r.prototype.m.progressEvents = u.r.prototype.m.Nd, 
    u.r.prototype.m.timeupdateEvents = u.r.prototype.m.Sd, $("videojs.Html5", u.l), 
    u.l.Events = u.l.$a, u.l.isSupported = u.l.isSupported, u.l.canPlaySource = u.l.mb, 
    u.l.prototype.setCurrentTime = u.l.prototype.sd, u.l.prototype.setVolume = u.l.prototype.xd, 
    u.l.prototype.setMuted = u.l.prototype.vd, u.l.prototype.setPreload = u.l.prototype.wd, 
    u.l.prototype.setAutoplay = u.l.prototype.rd, u.l.prototype.setLoop = u.l.prototype.ud, 
    $("videojs.Flash", u.f), u.f.isSupported = u.f.isSupported, u.f.canPlaySource = u.f.mb, 
    u.f.onReady = u.f.onReady, $("videojs.TextTrack", u.X), u.X.prototype.label = u.X.prototype.label, 
    $("videojs.CaptionsTrack", u.Ub), $("videojs.SubtitlesTrack", u.$b), $("videojs.ChaptersTrack", u.Vb), 
    $("videojs.autoSetup", u.fc), $("videojs.plugin", u.od), $("videojs.createTimeRange", u.tb);
}();