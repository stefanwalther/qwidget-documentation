define([ "jquery", "qvangular", "./../../modules/utils/wiUtils" ], function(a, b, c) {
    "use strict";
    b.directive("wiMediaBox", function() {
        var b = function(b, d, e) {
            function f() {
                switch (e.type.toLowerCase()) {
                  case "webpage":
                    g();
                    break;

                  case "video":
                    h();
                    break;

                  case "html":
                    i();
                    break;

                  default:
                    j();
                }
            }
            function g() {
                console.info("wiMediaBox:renderEmpty()"), console.debug(e);
                var c = a(document.createElement("div"));
                c.addClass("wiMediaBox_divContainer");
                var f = a(document.createElement("iframe"));
                if (f.attr("id", "iframe_" + b.layout.qInfo.qId), f.addClass("wiMediaBox_Iframe"), 
                f.attr("sandbox", "allow-scripts"), f.attr("src", e.url), f.attr("scrolling", e.scrolling), 
                void 0 !== e.width && f.width(e.width), void 0 !== e.height && f.height(e.height), 
                c.append(f), "true" === (e.preventInteraction || "true").toLowerCase()) {
                    if ("true" === (e.interactionMessage || "true").toLowerCase()) {
                        var g = a(document.createElement("div"));
                        g.attr("id", "wiMediaBox_divBlankMsg_" + b.layout.qInfo.qId), g.addClass("wiMediaBox_divBlankMsg"), 
                        g.html(e.interactionMessageText || "Interaction is disabled"), c.append(g);
                    }
                    var h = a(document.createElement("div"));
                    h.attr("id", "wiMediaBox_divBlank_" + b.layout.qInfo.qId), h.addClass("wiMediaBox_divBlank"), 
                    h.click(function() {
                        if ("true" === (e.interactionMessage || "").toLowerCase()) {
                            var c = a("#wiMediaBox_divBlankMsg_" + b.layout.qInfo.qId);
                            c.fadeIn(300).delay(2e3).fadeOut(5e3);
                        }
                        return !1;
                    }), c.append(h);
                }
                d.replaceWith(c);
            }
            function h() {
                console.log("render Video"), require([ "extensions/qwidget/components/wiMediaBox/video", "text!extensions/qwidget/components/wiMediaBox/video-js.min.css" ], function(f, g) {
                    if (c.addStyleToHeader("videoJs", g), 0 === a("#wiMediaBox_video_" + b.layout.qInfo.qId).length) {
                        console.log("add video");
                        var h = a(document.createElement("div"));
                        h.attr("id", "wiMediaBox_divContainer_" + b.layout.qInfo.qId), h.addClass("wiMediaBox_divContainer");
                        var i = a(document.createElement("video"));
                        i.attr("id", "wiMediaBox_video_" + b.layout.qInfo.qId), i.addClass("video-js"), 
                        i.addClass("vjs-default-skin"), i.attr("width", "100%"), i.attr("height", "100%"), 
                        i.attr("poster", "http://video-js.zencoder.com/oceans-clip.png");
                        var j = a(document.createElement("source"));
                        j.attr("src", e.url), j.attr("type", "video/mp4"), i.append(j), h.append(i), d.replaceWith(h);
                    } else console.log("change size of video");
                    videojs("wiMediaBox_video_" + b.layout.qInfo.qId, {
                        controls: !0,
                        autoplay: e.autoplay || !1,
                        preload: "auto"
                    }).ready(function() {
                        var a = this;
                        a.play();
                    });
                });
            }
            function i() {}
            function j() {
                console.info("wiMediaBox:renderEmpty()");
                var b = a(document.createElement("div"));
                b.html("Empty Media Box"), d.replaceWith(b);
            }
            b.$watch(function() {
                return {
                    t: e.type,
                    h: e.height,
                    w: e.width,
                    u: e.url,
                    s: e.scrolling
                };
            }, function(a, b) {
                return null !== a && a === b ? void console.log("Don't render, values are equal") : void (null !== a && void 0 !== a.w && (console.log("Render"), 
                f()));
            }, !0), f();
        };
        return {
            restrict: "E",
            replace: !0,
            priority: 0,
            link: b
        };
    });
});