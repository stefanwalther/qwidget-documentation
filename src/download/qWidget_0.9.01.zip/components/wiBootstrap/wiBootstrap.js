define([ "qvangular", "./../../modules/utils/wiUtils", "text!./css/wiBootstrap.css" ], function(a, b, c) {
    "use strict";
    b.addStyleToHeader("wiBootstrap", c), a.directive("wiBootstrap", function() {
        return {
            restrict: "E",
            replace: !0,
            transclude: !0,
            priority: 1e3,
            template: '<div class="wi-bs" ng-transclude></div>'
        };
    });
});