/*global define*/
define([
        'text!./fa-iconSizes.json',
        'text!./repositories.json',
        'text!./wiWidgetEditor.PopupPublish.PublishingModes.json'
    ],
    function (faIconSizes, repositories, publishingModes) {

        'use strict';
        return {
            IconSizes: JSON.parse(faIconSizes),
            Repositories: JSON.parse(repositories),
            RepositoriesJSON: '/extensions/qwidget/config/repositories.json',
            Link_NewVersion: 'http://qtarchlabeu04.qliktech.com:8080/qWidget/',
            PublishForm_PublishingModes: JSON.parse(publishingModes)

        };
    });