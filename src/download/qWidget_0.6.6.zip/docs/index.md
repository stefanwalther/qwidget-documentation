* [Introduction](#Introduction)
* [Getting Started](#GettingStarted)
* [Inspirations](#Inspirations)
* [Do you want to contribute?](#Contribute)


## <a name="Introduction"></a>Introduction
The basic idea behind qWidgets is that you should be able to create **new** visualizations without the need of programming them in JavaScript by leveraging Qlik Sense' extension concept.
By just using *Html & CSS* you can create completely new and astonishing objects in Qlik Sense which behave like all other objects and **even more**:

qWidgets can be
* Created by just copying Html & CSS from one of the thousands libraries out there ...
* Copied from one app to another app
* Put and to master-library and re-used from there
* Used in Stories
* Used **accross** apps and even installations of Qlik Sense

## <a name="GettingStarted"></a>Getting Started
A detailed step-by-step guide [can be found here](http://qtarchlabeu04.qliktech.com:8080/qWidget/#/GettingStarted).

## <a name="Inspirations"></a>Inspirations
Using the qWidget-concept more or less unlocks the Web, quite a lot of the visualizations you nowadays see in the internet can be brought easily into Qlik Sense.
For getting inspired, visit a [collection of visualization found recently somewhere in the web](http://qtarchlabeu04.qliktech.com:8080/qWidget/#/Examples).

## <a name="Contribute"></a>Do You Want to Contribute?

Do you like the concept? Nice!
There are a [lot of options](http://qtarchlabeu04.qliktech.com:8080/qWidget/#/Contribute) how you could help to make this concept a success!














