﻿/*global define, angular, qvangular*/
define([
	'jquery',
	'qvangular'
],
function ($, qvangular) {
    'use strict';

    qvangular.directive('uiAce', function () {
        return {
            restrict: 'AE',
            link: function (scope, elm, attrs, ngModel) {
                //console.log("Ace recognized");
                //console.log(ngModel);

                var options, opts, acee, session, onChange;

                //options = uiAceConfig.ace || {};
                options = {};

                opts = angular.extend({}, options, scope.$eval(attrs.uiAce));

                acee = window.ace.edit(elm[0]);
                session = acee.getSession();

                // Hardcoded Default values
                acee.setShowPrintMargin(false);

                onChange = function (callback) {
                    return function (e) {
                        var newValue = session.getValue();
                        if (newValue !== scope.$eval(attrs.value) && !scope.$$phase && !scope.$root.$$phase) {
                            if (angular.isDefined(ngModel)) {
                                scope.$apply(function () {
                                    ngModel.$setViewValue(newValue);
                                });
                            }

                            /**
                             * Call the user onChange function.
                             */
                            if (angular.isDefined(callback)) {
                                scope.$apply(function () {
                                    if (angular.isFunction(callback)) {
                                        callback(e, acee);
                                    }
                                    else {
                                        throw new Error('ui-ace use a function as callback.');
                                    }
                                });
                            }
                        }
                    };
                };

                // Additional options here: http://ace.c9.io/#nav=api&api=virtual_renderer

                // Boolean options
                if (angular.isDefined(opts.showGutter)) {
                    acee.renderer.setShowGutter(opts.showGutter);
                }
                if (angular.isDefined(opts.useWrapMode)) {
                    session.setUseWrapMode(opts.useWrapMode);
                }

                // Added by SWR
                if (angular.isDefined(opts.useAnnotations)) {
                    //console.log('opts.enableAnnotations', opts.useAnnotations);
                    session.setOption("useWorker", opts.useAnnotations);
                }
//                if (angular.isDefined(opts.fontsize)) {
//                    acee.setFontSize(opts.fontsize);
//                }
                // (End added by SWR)

                // onLoad callback
                if (angular.isFunction(opts.onLoad)) {
                    opts.onLoad(acee);
                }

                // Basic options
                if (angular.isString(opts.theme)) {
                    acee.setTheme('ace/theme/' + opts.theme);
                }
                if (angular.isString(opts.mode)) {
                    session.setMode('ace/mode/' + opts.mode);
                }

                attrs.$observe('readonly', function (value) {
                    acee.setReadOnly(value === 'true');
                });

                // Value Blind
                if (angular.isDefined(ngModel)) {
                    ngModel.$formatters.push(function (value) {
                        if (angular.isUndefined(value) || value === null) {
                            return '';
                        }
                        else if (angular.isObject(value) || angular.isArray(value)) {
                            throw new Error('ui-ace cannot use an object or an array as a model');
                        }
                        return value;
                    });

                    ngModel.$render = function () {
                        session.setValue(ngModel.$viewValue);
                    };
                }

                // EVENTS
                session.on('change', onChange(opts.onChange));

                elm.on('$destroy', function () {
                    acee.session.$stopWorker();
                    acee.destroy();
                });

                scope.$watch(function () {
                    return [elm[0].offsetWidth, elm[0].offsetHeight];
                }, function () {
                    acee.resize();
                    acee.renderer.updateFull();
                }, true);
            }
        };
    });

});
