/*global define,qvangular*/
define([
        'jquery',
        'qvangular'
    ],
    function ($, qvangular) {
        'use strict';
        qvangular.filter('wiRange', function() {
            return function(input) {
                var lowBound, highBound, step;
                switch (input.length) {
                    case 1:
                        lowBound = 0;
                        highBound = parseInt(input[0]) - 1;
                        step = 1;
                        break;
                    case 2:
                        lowBound = parseInt(input[0]);
                        highBound = parseInt(input[1]);
                        step = 1;
                        break;
                    case 3:
                        lowBound = parseInt(input[0]);
                        highBound = parseInt(input[1]);
                        step = parseInt(input[2]);
                        break;
                    default:
                        return input;
                }
                var result = [];
                for (var i = lowBound; i <= highBound; i+=step) {
                    result.push(i);
                }
                return result;
            };
        });
    });

