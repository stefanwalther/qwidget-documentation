* **wi-minichart** is realized based on the following sources
	* jquery.sparkline 2.1.2 - http://omnipotent.net/jquery.sparkline/
	* Licensed under the New BSD License - see above site for details