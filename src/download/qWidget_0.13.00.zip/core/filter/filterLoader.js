/*global define*/
define([
        'jquery',
        'qvangular',
        './wiRange'
        //,
        //'./wiSearchField'
    ],
    function ($, qvangular) {
        'use strict';
        return true;
    });
