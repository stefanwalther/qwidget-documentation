# qWidget

This is an internal prototype.
Please do NOT SHARE.

Further information + documentation: http://qtarchlabeu04.qliktech.com:8080/qWidget/